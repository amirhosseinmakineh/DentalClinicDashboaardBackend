using DentalDashboard.Domain.IRepositories;
using DentalDashboard.Domain.Models;
using DentalDashboard.Infrastracture.Context;
using Microsoft.EntityFrameworkCore;
using DentalDashboard.Domain.Enums;

namespace DentalDashboard.Infrastracture.Repository
{
    public class ReservationRepository : BaseRepository<long, Reservation>, IReservationRepository
    {
        public ReservationRepository(DentalContext context) : base(context)
        {
        }

        public Task<int> CountActiveReservationsAtAsync(long consultantProfileId, DateTime reservationAt)
        {
            return GetAll()
                .CountAsync(x => x.ConsultantProfileId == consultantProfileId &&
                                 x.ReservationAt == reservationAt &&
                                 !x.IsCanceled);
        }

        public Task<int> CountActiveReservationsAtExcludingAsync(
            long consultantProfileId,
            DateTime reservationAt,
            long excludeReservationId)
        {
            return GetAll()
                .CountAsync(x => x.ConsultantProfileId == consultantProfileId &&
                                 x.ReservationAt == reservationAt &&
                                 !x.IsCanceled &&
                                 x.Id != excludeReservationId);
        }

        public Task<bool> HasActiveReservationForLeadAsync(long leadAssignmentId)
        {
            return GetAll()
                .AnyAsync(x => x.LeadAssignmentId == leadAssignmentId &&
                               !x.IsCanceled &&
                               x.AttendanceConfirmationStatus != ReservationAttendanceConfirmationStatus.SecretaryApproved &&
                               x.AttendanceConfirmationStatus != ReservationAttendanceConfirmationStatus.SecretaryRejected);
        }
    }
}
