
using System.Security.Claims;
using DentalDashboard.ApplicationService.Contract.IServices;
using DentalDashboard.ApplicationService.Contract.Secretary.Accountant.PatientFinance.Commands;
using DentalDashboard.ApplicationService.Contract.Secretary.Accountant.PatientFinance.Queries;
using DentalDashboard.Framwork.Cqrs.Abstraction.Read;
using DentalDashboard.Framwork.Cqrs.Abstraction.Wrire;
using DentalDashboard.Framwork.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DentalDashboard.Secretary.Accountant.PatientFinance.Controllers;

[ApiController]
[Authorize(Roles = "Admin,Secretary")]
[Route("api/secretary")]
public sealed class PatientFinanceController(
    ICommandDispatcher commands,
    IQueryDispatcher queries,
    IFileStorageService storage) : ControllerBase
{
    private const long MaximumPatientDocumentBytes = 5 * 1024 * 1024;

    [HttpGet("patient-financial-cases/{id:guid}/additional-documents")]
    public async Task<IActionResult> GetAdditionalDocuments(
        Guid id,
        CancellationToken cancellationToken)
    {
        var documents = await queries.DispatchAsync(
            new GetPatientFinancialDocumentsQuery(id),
            cancellationToken);
        return Ok(Result<IReadOnlyList<PatientFinancialDocumentDto>>.Success(documents));
    }

    [HttpGet("patient-financial-cases/{id:guid}/additional-documents/{documentId:guid}/image")]
    public async Task<IActionResult> GetAdditionalDocumentImage(
        Guid id,
        Guid documentId,
        CancellationToken cancellationToken)
    {
        var document = await queries.DispatchAsync(
            new GetPatientFinancialDocumentFileQuery(id, documentId),
            cancellationToken);

        if (document is null)
        {
            return NotFound();
        }

        var image = storage.OpenPatientDocument(document.StoragePath);
        return image is null
            ? NotFound()
            : File(image, document.ContentType);
    }

    [HttpPost("patient-financial-cases/{id:guid}/additional-documents")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(MaximumPatientDocumentBytes + 4096)]
    public async Task<IActionResult> UploadAdditionalDocument(
        Guid id,
        IFormFile file,
        [FromForm] string? description,
        CancellationToken cancellationToken)
    {
        if (file is null || file.Length == 0 || file.Length > MaximumPatientDocumentBytes)
        {
            return BadRequest(Result.Failure("حجم تصویر باید بین ۱ بایت تا ۵ مگابایت باشد"));
        }

        if (description?.Length > 500)
        {
            return BadRequest(Result.Failure("توضیح مدرک حداکثر ۵۰۰ نویسه است"));
        }

        await using var data = new MemoryStream();
        await file.CopyToAsync(data, cancellationToken);
        var bytes = data.ToArray();
        var isPng = bytes.Length >= 8 &&
                    bytes[0] == 0x89 && bytes[1] == 0x50 &&
                    bytes[2] == 0x4E && bytes[3] == 0x47 &&
                    bytes[4] == 0x0D && bytes[5] == 0x0A &&
                    bytes[6] == 0x1A && bytes[7] == 0x0A;
        var isJpeg = bytes.Length >= 3 &&
                     bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF;

        if (!isPng && !isJpeg)
        {
            return BadRequest(Result.Failure("فقط تصاویر واقعی JPG و PNG مجاز هستند"));
        }

        data.Position = 0;
        var extension = isPng ? ".png" : ".jpg";
        var contentType = isPng ? "image/png" : "image/jpeg";
        var path = await storage.SavePatientDocumentAsync(
            data,
            extension,
            cancellationToken);

        try
        {
            var result = await commands.DispatchAsync(
                new AddPatientFinancialDocumentCommand(id, path, contentType, description),
                cancellationToken);

            if (!result.IsSuccess)
            {
                storage.DeletePatientDocument(path);
                return BadRequest(result);
            }

            return Ok(result);
        }
        catch
        {
            storage.DeletePatientDocument(path);
            throw;
        }
    }

    [HttpDelete("patient-financial-cases/{id:guid}/additional-documents/{documentId:guid}")]
    public async Task<IActionResult> DeleteAdditionalDocument(
        Guid id,
        Guid documentId,
        CancellationToken cancellationToken)
    {
        var result = await commands.DispatchAsync(
            new DeletePatientFinancialDocumentCommand(id, documentId),
            cancellationToken);
        return Write(result);
    }

    [HttpPost("patient-financial-cases/{id:guid}/guarantee-document")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(5 * 1024 * 1024)]
    public async Task<IActionResult> UploadGuaranteeDocument(Guid id, IFormFile file, CancellationToken cancellationToken)
    {
        if (file is null || file.Length == 0)
            return BadRequest(Result.Failure("فایل الزامی است"));

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (extension is not (".jpg" or ".jpeg" or ".png"))
            return BadRequest(Result.Failure("فقط فایل‌های jpg و png مجاز هستند"));

        await using var stream = file.OpenReadStream();
        var path = await storage.SaveAsync(stream, extension, cancellationToken);

        var result = await commands.DispatchAsync(new UploadGuaranteeDocumentCommand(id, path), cancellationToken);
        if (!result.IsSuccess)
        {
            storage.Delete(path);
            return BadRequest(result);
        }
        return Ok(result);
    }

    [HttpDelete("patient-financial-cases/{id:guid}/guarantee-document")]
    public async Task<IActionResult> DeleteGuaranteeDocument(Guid id, CancellationToken cancellationToken)
    {
        var result = await commands.DispatchAsync(new UploadGuaranteeDocumentCommand(id, string.Empty), cancellationToken);
        return result.IsSuccess ? Ok(result) : BadRequest(result);
    }

    [HttpPost("patient-financial-cases")]
    public async Task<IActionResult> Create(CreatePatientFinancialCaseCommand command, CancellationToken cancellationToken)
    {
        if (!UserId(out var userId))
            return Unauthorized();

        command.ActorUserId = userId;

        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpPut("patient-financial-cases/{id:guid}")]
    public async Task<IActionResult> Update(Guid id, UpdatePatientFinancialCaseCommand command, CancellationToken cancellationToken)
    {
        command.Id = id;

        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpDelete("patient-financial-cases/{id:guid}")]
    public async Task<IActionResult> Cancel(Guid id, CancellationToken cancellationToken)
    {
        return Write(await commands.DispatchAsync(new CancelPatientFinancialCaseCommand(id), cancellationToken));
    }

    [HttpPost("patient-financial-cases/{caseId:guid}/cheques")]
    public async Task<IActionResult> AddCheque(Guid caseId, CreatePatientChequeDto dto, CancellationToken cancellationToken)
    {
        var command = new AddPatientChequeCommand(
            caseId,
            dto.Amount,
            dto.SayadNumber,
            dto.OwnerName,
            dto.DueDate,
            dto.IsGuarantee);

        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpPost("patient-financial-cases/{caseId:guid}/promissory-notes")]
    public async Task<IActionResult> AddNote(Guid caseId, CreatePatientPromissoryNoteDto dto, CancellationToken cancellationToken)
    {
        var command = new AddPatientPromissoryNoteCommand(
            caseId,
            dto.SerialNumber,
            dto.Amount,
            dto.DueDate);

        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpPut("patient-cheques/{id:long}/status")]
    public async Task<IActionResult> ChequeStatus(long id, UpdatePatientChequeStatusCommand command, CancellationToken cancellationToken)
    {
        if (!UserId(out var userId))
            return Unauthorized();

        command.ChequeId = id;
        command.ActorUserId = userId;

        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpPut("patient-cheques/{id:long}")]
    public async Task<IActionResult> UpdateCheque(long id, UpdatePatientChequeCommand command, CancellationToken cancellationToken)
    {
        command.ChequeId = id;
        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpDelete("patient-cheques/{id:long}")]
    public async Task<IActionResult> DeleteCheque(long id, CancellationToken cancellationToken)
    {
        return Write(await commands.DispatchAsync(new DeletePatientChequeCommand(id), cancellationToken));
    }

    [HttpPut("patient-promissory-notes/{id:long}")]
    public async Task<IActionResult> UpdateNote(long id, UpdatePatientPromissoryNoteCommand command, CancellationToken cancellationToken)
    {
        command.PromissoryNoteId = id;
        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpDelete("patient-promissory-notes/{id:long}")]
    public async Task<IActionResult> DeleteNote(long id, CancellationToken cancellationToken)
    {
        return Write(await commands.DispatchAsync(new DeletePatientPromissoryNoteCommand(id), cancellationToken));
    }

    [HttpPut("patient-promissory-notes/{id:long}/status")]
    public async Task<IActionResult> NoteStatus(long id, UpdatePatientPromissoryNoteStatusCommand command, CancellationToken cancellationToken)
    {
        if (!UserId(out var userId))
            return Unauthorized();

        command.PromissoryNoteId = id;
        command.ActorUserId = userId;

        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpPost("patient-debts/{id:long}/pay")]
    public async Task<IActionResult> PayDebt(long id, CancellationToken cancellationToken)
    {
        if (!UserId(out var userId))
            return Unauthorized();

        var command = new PayPatientDebtCommand
        {
            DebtId = id,
            ActorUserId = userId
        };

        return Write(await commands.DispatchAsync(command, cancellationToken));
    }

    [HttpGet("patient-financial-cases")]
    public async Task<IActionResult> Cases([FromQuery] GetPatientFinancialCasesQuery query, CancellationToken cancellationToken)
    {
        return Ok(await queries.DispatchAsync(query, cancellationToken));
    }

    [HttpGet("patient-financial-cases/{id:guid}")]
    public async Task<IActionResult> Details(Guid id, CancellationToken cancellationToken)
    {
        var result = await queries.DispatchAsync(new GetPatientFinancialCaseDetailsQuery(id), cancellationToken);

        return result is null
            ? NotFound(Result<object?>.Failure("پرونده مالی موردنظر یافت نشد."))
            : Ok(Result<PatientFinancialCaseDetailsDto>.Success(
                result, "اطلاعات پرونده مالی دریافت شد."));
    }

    [HttpGet("patient-financial-cases/{id:guid}/summary")]
    public async Task<IActionResult> CaseSummary(Guid id, CancellationToken cancellationToken)
    {
        var result = await queries.DispatchAsync(new GetPatientFinancialCaseSummaryQuery(id), cancellationToken);

        return result is null
            ? NotFound(Result<object?>.Failure("پرونده مالی موردنظر یافت نشد."))
            : Ok(Result<PatientFinancialCaseSummaryDto>.Success(
                result, "خلاصه مالی پرونده دریافت شد."));
    }

    [HttpGet("patients/{id:guid}/financial-summary")]
    public async Task<IActionResult> PatientSummary(Guid id, CancellationToken cancellationToken)
    {
        var result = await queries.DispatchAsync(new GetPatientFinancialSummaryQuery(id), cancellationToken);

        return result is null
            ? NotFound(Result.Failure("اطلاعات مالی بیمار یافت نشد"))
            : Ok(result);
    }

    [HttpGet("patient-cheques")]
    public async Task<IActionResult> Cheques([FromQuery] GetPatientChequesQuery query, CancellationToken cancellationToken)
    {
        return Ok(await queries.DispatchAsync(query, cancellationToken));
    }

    [HttpGet("patient-promissory-notes")]
    public async Task<IActionResult> Notes([FromQuery] GetPatientPromissoryNotesQuery query, CancellationToken cancellationToken)
    {
        return Ok(await queries.DispatchAsync(query, cancellationToken));
    }

    [HttpGet("patient-debts")]
    public async Task<IActionResult> Debts([FromQuery] GetPatientDebtsQuery query, CancellationToken cancellationToken)
    {
        return Ok(await queries.DispatchAsync(query, cancellationToken));
    }

    [HttpGet("patient-financial-transactions")]
    public async Task<IActionResult> Transactions([FromQuery] GetPatientFinancialTransactionsQuery query, CancellationToken cancellationToken)
    {
        return Ok(await queries.DispatchAsync(query, cancellationToken));
    }

    [HttpGet("patient-financial-commitments/due")]
    public async Task<IActionResult> Due([FromQuery] GetDuePatientFinancialCommitmentsQuery query, CancellationToken cancellationToken)
    {
        return Ok(await queries.DispatchAsync(query, cancellationToken));
    }

    private IActionResult Write<T>(Result<T> result)
    {
        if (result.IsSuccess)
            return Ok(result);

        if (result.Message.Contains("یافت نشد"))
            return NotFound(result);

        if (result.Message.Contains("قابل ویرایش نیست") ||
            result.Message.Contains("قابل لغو") ||
            result.Message.Contains("روز سررسید") ||
            result.Message.Contains("قبلاً تعیین شده") ||
            result.Message.Contains("تسویه کامل بدهی امکان‌پذیر نیست"))
            return Conflict(result);

        return BadRequest(result);
    }

    private bool UserId(out Guid id)
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier)
                     ?? User.FindFirstValue("userId")
                     ?? User.FindFirstValue("Id");

        return Guid.TryParse(userId, out id);
    }
}
