using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.Entities;
using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.IRepositories;
using DentalDashboard.Infrastracture.Context;

namespace DentalDashboard.Infrastracture.Secretary.Accountant.PatientFinance.Repositories;
public sealed class PatientFinanceRepository(DentalContext context)
    : IPatientFinanceRepository {
  public IQueryable<PatientFinancialCase> Cases =>
      context.PatientFinancialCases;
  public IQueryable<PatientFinancialDocument> Documents => context.PatientFinancialDocuments;
  public IQueryable<PatientCheque> Cheques => context.PatientCheques;
  public IQueryable<PatientPromissoryNote> PromissoryNotes =>
      context.PatientPromissoryNotes;
  public IQueryable<PatientDebt> Debts => context.PatientDebts;
  public IQueryable<PatientFinancialTransaction> Transactions =>
      context.PatientFinancialTransactions;
  public IQueryable<DentalDashboard.Domain.Models.User> Patients =>
      context.Users;
  public IQueryable<DentalDashboard.Domain.Models.PatientFile> PatientFiles =>
      context.PatientFiles;
  public Task AddCaseAsync(PatientFinancialCase x, CancellationToken ct) =>
      context.PatientFinancialCases.AddAsync(x, ct).AsTask();
  public Task AddDocumentAsync(PatientFinancialDocument entity, CancellationToken ct) =>
      context.PatientFinancialDocuments.AddAsync(entity, ct).AsTask();
  public Task AddChequeAsync(PatientCheque x, CancellationToken ct) =>
      context.PatientCheques.AddAsync(x, ct).AsTask();
  public Task AddPromissoryNoteAsync(PatientPromissoryNote x,
                                     CancellationToken ct) =>
      context.PatientPromissoryNotes.AddAsync(x, ct).AsTask();
  public Task AddDebtAsync(PatientDebt x, CancellationToken ct) =>
      context.PatientDebts.AddAsync(x, ct).AsTask();
  public Task AddTransactionAsync(PatientFinancialTransaction x,
                                  CancellationToken ct) =>
      context.PatientFinancialTransactions.AddAsync(x, ct).AsTask();
}
