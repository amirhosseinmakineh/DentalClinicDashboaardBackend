using DentalDashboard.Domain.Enums;
using DentalDashboard.Domain.IRepositories;
using DentalDashboard.Domain.Models;
using DentalDashboard.Infrastracture.Context;
using DentalDashboard.Utilities.Time;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace DentalDashboard.Infrastracture.Repository
{
    public class LeadAssignmentRepository : BaseRepository<long, LeadAssignment>, ILeadAssignmentRepository
    {
        public LeadAssignmentRepository(DentalContext context) : base(context)
        {
        }

        public Task<List<LeadAssignment>> GetUnassignedRealTimeLeadsAsync(int take)
        {
            return GetAll()
                .Where(x => !x.IsDeleted &&
                            x.AssignmentType == LeadAssignmentType.RealTime &&
                            x.ConsultantProfileId == null &&
                            x.ReportSubmittedAt == null &&
                            x.LeadAssignmentState == LeadAssignmentState.New &&
                            x.PickUp == false &&
                            !context.LeadAssignments.Any(previous =>
                                previous.Id != x.Id &&
                                previous.PhoneNumber == x.PhoneNumber &&
                                previous.ReportSubmittedAt != null))
                .OrderBy(x => x.CreatedAt)
                .ThenBy(x => x.Id)
                .Take(take)
                .ToListAsync();
        }

        public Task<List<LeadAssignment>> GetRealtimeLeadsForDispatchAsync(
            int take,
            TimeSpan redispatchInterval)
        {
            var redispatchBefore = DateTime.UtcNow.Subtract(redispatchInterval);

            return GetAll()
                .Where(x => !x.IsDeleted &&
                            x.AssignmentType == LeadAssignmentType.RealTime &&
                            x.ConsultantProfileId == null &&
                            x.ReportSubmittedAt == null &&
                            x.LeadAssignmentState == LeadAssignmentState.New &&
                            !x.PickUp &&
                            !context.LeadAssignments.Any(previous =>
                                previous.Id != x.Id &&
                                previous.PhoneNumber == x.PhoneNumber &&
                                previous.ReportSubmittedAt != null) &&
                            (!x.NotificationSent ||
                             x.LastDispatchAt == null ||
                             x.LastDispatchAt < redispatchBefore))
                .OrderByDescending(x => x.CreatedAt)
                .ThenBy(x => x.Id)
                .Take(take)
                .ToListAsync();
        }

        public async Task<LeadAssignment?> GetActiveRealtimeBroadcastLeadAsync()
        {
            var baseQuery = GetAll()
                .Where(x => !x.IsDeleted &&
                            x.AssignmentType == LeadAssignmentType.RealTime &&
                            x.ConsultantProfileId == null &&
                            x.ReportSubmittedAt == null &&
                            x.LeadAssignmentState == LeadAssignmentState.New &&
                            !x.PickUp &&
                            !context.LeadAssignments.Any(previous =>
                                previous.Id != x.Id &&
                                previous.PhoneNumber == x.PhoneNumber &&
                                previous.ReportSubmittedAt != null));

            var inFlightLead = await baseQuery
                .Where(x => x.NotificationSent)
                .OrderByDescending(x =>  x.CreatedAt)
                .ThenBy(x => x.Id)
                .FirstOrDefaultAsync();

            if (inFlightLead != null)
                return inFlightLead;

            return await baseQuery
                .Where(x => !x.NotificationSent)
                .OrderByDescending(x => x.CreatedAt)
                .ThenBy(x => x.Id)
                .FirstOrDefaultAsync();
        }

        public async Task<LeadAssignment?> GetCurrentRealtimeLeadForDispatchAsync(
            TimeSpan redispatchInterval, LeadSourceType? sourceType = null)
        {
            var query = GetAll().Where(x => !x.IsDeleted && x.AssignmentType == LeadAssignmentType.RealTime && x.ConsultantProfileId == null && x.ReportSubmittedAt == null && x.LeadAssignmentState == LeadAssignmentState.New && !x.PickUp && !context.LeadAssignments.Any(previous => previous.Id != x.Id && previous.PhoneNumber == x.PhoneNumber && previous.ReportSubmittedAt != null));
            if (sourceType.HasValue)
                query = sourceType.Value == LeadSourceType.Yektanet
                    ? query.Where(x => x.SourceType == LeadSourceType.Yektanet || x.SourceType == LeadSourceType.Website || x.SourceType == LeadSourceType.SmsPanel)
                    : query.Where(x => x.SourceType == sourceType.Value);

            var lead = await query.Where(x => x.NotificationSent).OrderByDescending(x => x.CreatedAt).ThenBy(x => x.Id).FirstOrDefaultAsync()
                ?? await query.Where(x => !x.NotificationSent).OrderByDescending(x => x.CreatedAt).ThenBy(x => x.Id).FirstOrDefaultAsync();
            if (lead == null)
                return null;
            if (!lead.NotificationSent)
                return lead;
            var redispatchBefore = DateTime.UtcNow.Subtract(redispatchInterval);
            return lead.LastDispatchAt == null || lead.LastDispatchAt < redispatchBefore ? lead : null;
        }

        public Task<LeadSourceType?> GetLastPickedRealtimeSourceAsync()
        {
            return GetAll()
                .Where(x => x.AssignmentType == LeadAssignmentType.RealTime && x.ConsultantProfileId != null && x.AssignedAt != null && (x.SourceType == LeadSourceType.Yektanet || x.SourceType == LeadSourceType.Website || x.SourceType == LeadSourceType.AdminSheet))
                .OrderByDescending(x => x.AssignedAt).ThenByDescending(x => x.Id)
                .Select(x => (LeadSourceType?)x.SourceType)
                .FirstOrDefaultAsync();
        }

        private IQueryable<LeadAssignment> BurnedLeads() =>
            context.LeadAssignments.IgnoreQueryFilters().Where(x =>
                (x.IsDeleted &&
                 x.ConsultantProfileId == null &&
                 !x.PickUp) ||
                (!x.IsDeleted &&
                 x.ConsultantProfileId != null &&
                 x.LeadAssignmentState != LeadAssignmentState.ClosedByConsultant &&
                 x.CallResult == LeadCallResult.NoAnswer &&
                 x.ReportSubmittedAt != null));

        public async Task<LeadAssignment?> GetActiveBurnedLeadAsync()
        {
            var candidates = BurnedLeads();
            return await candidates
                .Where(x => x.NotificationSent)
                .OrderByDescending(x => x.CreatedAt)
                .ThenByDescending(x => x.Id)
                .FirstOrDefaultAsync()
                ?? await candidates
                    .Where(x => !x.NotificationSent)
                    .OrderByDescending(x => x.CreatedAt)
                    .ThenByDescending(x => x.Id)
                    .FirstOrDefaultAsync();
        }

        public async Task<LeadAssignment?> GetCurrentBurnedLeadForDispatchAsync(TimeSpan redispatchInterval)
        {
            var lead = await GetActiveBurnedLeadAsync();
            if (lead == null || !lead.NotificationSent)
                return lead;

            return lead.LastDispatchAt == null || lead.LastDispatchAt < DateTime.UtcNow.Subtract(redispatchInterval)
                ? lead
                : null;
        }

        public Task<bool> HasActiveRealTimeLeadAsync(long consultantProfileId)
        {
            return ActiveRealTimeLeadsForConsultant(consultantProfileId).AnyAsync();
        }

        public Task<int> CountActiveUnreportedRealTimeLeadsAsync(long consultantProfileId)
        {
            return ActiveRealTimeLeadsForConsultant(consultantProfileId)
                .CountAsync();
        }

        public Task<int> CountActiveUncalledRealTimeLeadsAsync(long consultantProfileId)
        {
            return ActiveRealTimeLeadsForConsultant(consultantProfileId)
                .CountAsync(x => x.CallInitiatedAt == null);
        }

        public Task<int> CountActiveFollowUpRealTimeLeadsAsync(long consultantProfileId)
        {
            return GetAll()
                .CountAsync(x => !x.IsDeleted &&
                                 x.ConsultantProfileId == consultantProfileId &&
                                 x.AssignmentType == LeadAssignmentType.RealTime &&
                                 x.PickUp &&
                                 x.AssignedAt != null &&
                                 x.LeadAssignmentState == LeadAssignmentState.Pending &&
                                 x.ReportSubmittedAt != null);
        }

        private IQueryable<LeadAssignment> ActiveRealTimeLeadsForConsultant(long consultantProfileId)
        {
            return GetAll()
                .Where(x => !x.IsDeleted &&
                            x.ConsultantProfileId == consultantProfileId &&
                            x.AssignmentType == LeadAssignmentType.RealTime &&
                            x.AssignedAt != null &&
                            x.ReportSubmittedAt == null &&
                            x.LeadAssignmentState != LeadAssignmentState.ClosedByConsultant);
        }

        public Task<List<LeadAssignment>> GetExpiredRealTimeLeadsAsync(DateTime now)
        {
            return GetAll()
                .Include(x => x.ConsultantProfile!)
                .Where(x => !x.IsDeleted &&
                            x.AssignmentType == LeadAssignmentType.RealTime &&
                            x.RequiresThreeMinuteCall &&
                            x.LeadAssignmentState == LeadAssignmentState.Assigned &&
                            x.ReportSubmittedAt == null &&
                            x.CallInitiatedAt == null &&
                            x.CallDeadlineAt != null &&
                            x.CallDeadlineAt < now)
                .ToListAsync();
        }

        public Task<int> CountUnassignedRealTimeLeadsAsync()
        {
            return GetAll()
                .CountAsync(x => !x.IsDeleted &&
                                 x.AssignmentType == LeadAssignmentType.RealTime &&
                                 x.ConsultantProfileId == null &&
                                 x.ReportSubmittedAt == null &&
                                 x.LeadAssignmentState == LeadAssignmentState.New);
        }

        public async Task<HashSet<string>> GetExistingPhoneNumbersAsync(
            IEnumerable<string> phoneNumbers,
            CancellationToken cancellationToken = default)
        {
            const int batchSize = 500;
            var phones = phoneNumbers
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .ToArray();
            var existingPhones = new HashSet<string>();

            foreach (var batch in phones.Chunk(batchSize))
            {
                var matches = await GetAll()
                    .AsNoTracking()
                    .Where(x => batch.Contains(x.PhoneNumber))
                    .Select(x => x.PhoneNumber)
                    .ToListAsync(cancellationToken);

                existingPhones.UnionWith(matches);
            }

            return existingPhones;
        }

        public async Task<int> AddNewLeadsIfPhoneDoesNotExistAsync(
            IEnumerable<LeadAssignment> leads,
            CancellationToken cancellationToken = default)
        {
            var candidates = leads
                .Where(x => !string.IsNullOrWhiteSpace(x.PhoneNumber))
                .GroupBy(x => x.PhoneNumber, StringComparer.Ordinal)
                .Select(x => x.First())
                .ToList();

            if (candidates.Count == 0)
                return 0;

            await using var transaction = await context.Database
                .BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);

            var phoneNumbers = candidates.Select(x => x.PhoneNumber).ToArray();
            var existingPhoneNumbers = await context.LeadAssignments
                .Where(x => phoneNumbers.Contains(x.PhoneNumber))
                .Select(x => x.PhoneNumber)
                .ToHashSetAsync(cancellationToken);

            var newLeads = candidates
                .Where(x => !existingPhoneNumbers.Contains(x.PhoneNumber))
                .ToList();

            if (newLeads.Count == 0)
            {
                await transaction.CommitAsync(cancellationToken);
                return 0;
            }

            await context.LeadAssignments.AddRangeAsync(newLeads, cancellationToken);
            await context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            return newLeads.Count;
        }

        public Task<LeadAssignment?> GetByIdAndConsultantAsync(long leadAssignmentId, long consultantProfileId)
        {
            return GetAll()
                .FirstOrDefaultAsync(x => !x.IsDeleted && x.Id == leadAssignmentId && x.ConsultantProfileId == consultantProfileId);
        }

        public Task<List<LeadAssignment>> GetAssignedLeadsPendingNotificationAsync()
        {
            return GetAll()
                .Include(x => x.ConsultantProfile)
                .ThenInclude(x => x.User)
                .Where(x => !x.IsDeleted &&
                            x.ConsultantProfileId.HasValue &&
                            !x.NotificationSent &&
                            x.LeadAssignmentState == LeadAssignmentState.Assigned)
                .OrderBy(x => x.AssignedAt)
                .ThenBy(x => x.Id)
                .ToListAsync();
        }

        public async Task<int> GetTodayPickupCountAsync(long consultantProfileId)
        {
            var today = IranTimeHelper.TodayInIran();
            var (todayStartUtc, _) = IranTimeHelper.GetIranDayRangeAsUtc(today);
            var (tomorrowStartUtc, _) = IranTimeHelper.GetIranDayRangeAsUtc(today.AddDays(1));

            return await context.LeadAssignments
                .CountAsync(x =>
                    !x.IsDeleted &&
                    x.ConsultantProfileId == consultantProfileId &&
                    x.PickUp &&
                    x.AssignedAt >= todayStartUtc &&
                    x.AssignedAt < tomorrowStartUtc);
        }

        public async Task<int> GetTodayCallCountAsync(long consultantProfileId)
        {
            var today = IranTimeHelper.TodayInIran();
            var (todayStartUtc, _) = IranTimeHelper.GetIranDayRangeAsUtc(today);
            var (tomorrowStartUtc, _) = IranTimeHelper.GetIranDayRangeAsUtc(today.AddDays(1));

            return await context.LeadAssignments
                .AsNoTracking()
                .CountAsync(x =>
                    !x.IsDeleted &&
                    x.ConsultantProfileId == consultantProfileId &&
                    x.CallInitiatedAt >= todayStartUtc &&
                    x.CallInitiatedAt < tomorrowStartUtc);
        }

        public async Task<bool> TryPickupLeadAsync(
            long leadAssignmentId,
            long consultantProfileId,
            CancellationToken cancellationToken)
        {
            var preferredSourceType = await context.ConsultantProfiles.AsNoTracking()
                .Where(x => x.Id == consultantProfileId && !x.IsDeleted)
                .Select(x => x.PreferredLeadSourceType)
                .SingleOrDefaultAsync(cancellationToken);
            var sourceType = preferredSourceType ?? await context.LeadAssignmentSettings.AsNoTracking()
                .Where(x => x.Id == LeadAssignmentSetting.SingletonId)
                .Select(x => x.AssignmentSourceType)
                .SingleOrDefaultAsync(cancellationToken);
            if (!Enum.IsDefined(sourceType))
                sourceType = LeadAssignmentSourceType.NewLeads;

            var sql = @"
        UPDATE LeadAssignments WITH (UPDLOCK, ROWLOCK)
        SET
            ConsultantProfileId = @consultantProfileId,
            IsDeleted = 0,
            DeletedAt = NULL,
            PickUp = 1,
            AssignedAt = GETUTCDATE(),
            CallDeadlineAt = DATEADD(MINUTE, 3, GETUTCDATE()),
            CallInitiatedAt = NULL,
            LeadAssignmentState = @assignedState,
            AssignmentType = @realTimeType,
            RequiresThreeMinuteCall = 1,
            ReportDescription = CASE WHEN @sourceType = @burnedSource THEN NULL ELSE ReportDescription END,
            ReportSubmittedAt = CASE WHEN @sourceType = @burnedSource THEN NULL ELSE ReportSubmittedAt END,
            ContactedAt = CASE WHEN @sourceType = @burnedSource THEN NULL ELSE ContactedAt END,
            CallResult = CASE WHEN @sourceType = @burnedSource THEN NULL ELSE CallResult END
        WHERE Id = @leadAssignmentId
          AND ((@sourceType = @newSource AND IsDeleted = 0 AND ConsultantProfileId IS NULL
                AND PickUp = 0 AND ReportSubmittedAt IS NULL AND LeadAssignmentState = @newState
                AND NOT EXISTS (
                    SELECT 1 FROM LeadAssignments previous
                    WHERE previous.Id <> LeadAssignments.Id
                      AND previous.PhoneNumber = LeadAssignments.PhoneNumber
                      AND previous.ReportSubmittedAt IS NOT NULL
                ))
            OR (@sourceType = @burnedSource
                AND ((IsDeleted = 1 AND ConsultantProfileId IS NULL AND PickUp = 0)
                  OR (IsDeleted = 0 AND ConsultantProfileId IS NOT NULL
                    AND LeadAssignmentState <> @closedByConsultantState
                    AND CallResult = @noAnswerResult
                    AND ReportSubmittedAt IS NOT NULL))))
    ";

            var affectedRows = await context.Database
                .ExecuteSqlRawAsync(
                    sql,
                    new SqlParameter(
                        "@consultantProfileId",
                        consultantProfileId),
                    new SqlParameter(
                        "@leadAssignmentId",
                        leadAssignmentId),
                    new SqlParameter(
                        "@assignedState",
                        (int)LeadAssignmentState.Assigned),
                    new SqlParameter("@newState", (int)LeadAssignmentState.New),
                    new SqlParameter("@closedByConsultantState", (int)LeadAssignmentState.ClosedByConsultant),
                    new SqlParameter("@noAnswerResult", (int)LeadCallResult.NoAnswer),
                    new SqlParameter("@realTimeType", (int)LeadAssignmentType.RealTime),
                    new SqlParameter("@sourceType", (int)sourceType),
                    new SqlParameter("@newSource", (int)LeadAssignmentSourceType.NewLeads),
                    new SqlParameter("@burnedSource", (int)LeadAssignmentSourceType.BurnedLeads)
                );

            return affectedRows == 1;
        }
    }
}
