﻿namespace DentalDashboard.ApplicationService.Contract.Responses.RoleResponse
{
    public record RoleItemsResponse : BaseResponse<long>
    {
        public string RoleName { get; set; } = default!;
    }
}
