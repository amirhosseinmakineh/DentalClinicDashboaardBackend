using DentalDashboard.ApplicationService.Contract.Requests.Lead.Queryies;
using DentalDashboard.ApplicationService.Contract.Responses;
using DentalDashboard.ApplicationService.Contract.Responses.LeadResponse;
using DentalDashboard.ApplicationService.Handlers.Helpers;
using DentalDashboard.Domain.IRepositories;
using Microsoft.EntityFrameworkCore;

namespace DentalDashboard.ApplicationService.Handlers.QueryHandlers.Lead
{
    public class GetLeadsAssignmentQueryHandler : IQueryHandler<GetLeadsQuery, PaginatedResult<LeadsAssignmentItemsResponse>>
    {
        private readonly ILeadAssignmentRepository leadAssignmentRepository;
        private readonly IReservationRepository reservationRepository;

        public GetLeadsAssignmentQueryHandler(ILeadAssignmentRepository leadAssignmentRepository, IReservationRepository reservationRepository)
        {
            this.leadAssignmentRepository = leadAssignmentRepository;
            this.reservationRepository = reservationRepository;
        }

        public async Task<PaginatedResult<LeadsAssignmentItemsResponse>> HandleAsync(GetLeadsQuery query, CancellationToken cancellationToken = default)
        {
            var leadsQuery = leadAssignmentRepository.GetAll()
                .AsNoTracking()
                .Where(x => !x.IsDeleted &&
                            x.ConsultantProfileId == query.ProfileId &&
                            x.LeadAssignmentState != LeadAssignmentState.ClosedByConsultant);

            if (query.SourceType.HasValue)
                leadsQuery = leadsQuery.Where(x => x.SourceType == query.SourceType.Value);

            if (query.leadAssignmentState.HasValue)
            {
                leadsQuery = leadsQuery.Where(x => x.LeadAssignmentState == query.leadAssignmentState.Value);
            }

            if (query.LeadAssignmentType.HasValue)
            {
                leadsQuery = leadsQuery.Where(x => x.AssignmentType == query.LeadAssignmentType.Value);
            }

            if (query.HasSubmittedReport.HasValue)
            {
                leadsQuery = query.HasSubmittedReport.Value
                    ? leadsQuery.Where(x => x.ReportSubmittedAt != null)
                    : leadsQuery.Where(x => x.ReportSubmittedAt == null);
            }

            if (!string.IsNullOrWhiteSpace(query.SearchText))
            {
                var searchText = query.SearchText.Trim();
                leadsQuery = leadsQuery.Where(x =>
                    x.UserName.Contains(searchText) ||
                    x.PhoneNumber.Contains(searchText) ||
                    (x.SecondaryPhoneNumber != null && x.SecondaryPhoneNumber.Contains(searchText)) ||
                    (x.PatientCity != null && x.PatientCity.Contains(searchText)) ||
                    (x.PatientRegion != null && x.PatientRegion.Contains(searchText)) ||
                    (x.ReportDescription != null && x.ReportDescription.Contains(searchText)));
            }

            if (!string.IsNullOrWhiteSpace(query.UserName))
            {
                var userName = query.UserName.Trim();
                leadsQuery = leadsQuery.Where(x => x.UserName.Contains(userName));
            }

            if (!string.IsNullOrWhiteSpace(query.PhoneNumber))
            {
                var phoneNumber = query.PhoneNumber.Trim();
                leadsQuery = leadsQuery.Where(x =>
                    x.PhoneNumber.Contains(phoneNumber) ||
                    (x.SecondaryPhoneNumber != null && x.SecondaryPhoneNumber.Contains(phoneNumber)));
            }

            if (!string.IsNullOrWhiteSpace(query.PatientCity))
            {
                var patientCity = query.PatientCity.Trim();
                leadsQuery = leadsQuery.Where(x =>
                    x.PatientCity != null && x.PatientCity.Contains(patientCity));
            }

            leadsQuery = leadsQuery.ApplyAssignedAtFilter(query);

            var allLeads = leadsQuery.Select(x => new LeadsAssignmentItemsResponse()
            {
                Id = x.Id,
                SourceType = x.SourceType,
                LeadAssignmentState = x.LeadAssignmentState,
                leadAssignmentType = x.AssignmentType,
                PhoneNumber = x.PhoneNumber,
                UserName = x.UserName,
                CreatedAt = x.CreatedAt,
                AssignedAt = x.AssignedAt,
                CallDeadlineAt = x.CallDeadlineAt,
                RequiresThreeMinuteCall = x.RequiresThreeMinuteCall,
                IsReportSubmitted = x.ReportSubmittedAt != null,
                ReportSubmittedAt = x.ReportSubmittedAt,
                ContactedAt = x.ContactedAt,
                CallInitiatedAt = x.CallInitiatedAt,
                CallResult = x.CallResult,
                ReportDescription = x.ReportDescription,
                PatientCity = x.PatientCity,
                PatientRegion = x.PatientRegion,
                BusinessName = x.BusinessName,
                ConsultantProfileId = x.ConsultantProfileId,
                AttendanceProbabilityPercent = x.AttendanceProbabilityPercent,
                SecondaryPhoneNumber = x.SecondaryPhoneNumber,
                HasActiveReservation = reservationRepository.GetAll()
                    .Any(r => !r.IsDeleted && !r.IsCanceled && r.LeadAssignmentId == x.Id),
                ClosedByConsultantAt = x.ClosedByConsultantAt,
                ClosureReason = x.ClosureReason,
                ClosureDescription = x.ClosureDescription
            });

            return await LeadAssignmentPagination.ToPaginatedResultAsync(allLeads, query.PageNumber, query.PageSize, cancellationToken);
        }
    }

    internal static class LeadAssignmentPagination
    {
        public static async Task<PaginatedResult<LeadsAssignmentItemsResponse>> ToUnpaginatedResultAsync(
            IQueryable<LeadsAssignmentItemsResponse> query,
            CancellationToken cancellationToken)
        {
            var totalCount = await query.CountAsync(cancellationToken);
            var items = await query
                .OrderByDescending(x => x.AssignedAt.HasValue)
                .ThenByDescending(x => x.AssignedAt)
                .ThenByDescending(x => x.Id)
                .ToListAsync(cancellationToken);

            return new PaginatedResult<LeadsAssignmentItemsResponse>
            {
                Items = items,
                TotalCount = totalCount
            };
        }

        public static async Task<PaginatedResult<LeadsAssignmentItemsResponse>> ToPaginatedResultAsync(
            IQueryable<LeadsAssignmentItemsResponse> query,
            int requestedPageNumber,
            int requestedPageSize,
            CancellationToken cancellationToken)
        {
            var pageNumber = Math.Clamp(requestedPageNumber, 1, 1_000_000);
            var pageSize = Math.Clamp(requestedPageSize, 1, 100);
            var totalCount = await query.CountAsync(cancellationToken);
            var items = await query
                .OrderByDescending(x => x.AssignedAt.HasValue)
                .ThenByDescending(x => x.AssignedAt)
                .ThenByDescending(x => x.Id)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync(cancellationToken);

            return new PaginatedResult<LeadsAssignmentItemsResponse>()
            {
                Items = items,
                TotalCount = totalCount,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }
    }

    public class GetAllLeadsAssignmentQueryHandler : IQueryHandler<GetAllLeadsQuery, PaginatedResult<LeadsAssignmentItemsResponse>>
    {
        private readonly ILeadAssignmentRepository leadAssignmentRepository;
        private readonly IReservationRepository reservationRepository;

        public GetAllLeadsAssignmentQueryHandler(
            ILeadAssignmentRepository leadAssignmentRepository,
            IReservationRepository reservationRepository)
        {
            this.leadAssignmentRepository = leadAssignmentRepository;
            this.reservationRepository = reservationRepository;
        }

        public async Task<PaginatedResult<LeadsAssignmentItemsResponse>> HandleAsync(GetAllLeadsQuery query, CancellationToken cancellationToken = default)
        {
            var leadsQuery = leadAssignmentRepository.GetAll().Where(x => !x.IsDeleted);

            if (query.ReservationOptionsOnly)
            {
                leadsQuery = leadsQuery.Where(x =>
                    x.ReportSubmittedAt.HasValue &&
                    (x.CallResult == LeadCallResult.Contacted || x.CallResult == LeadCallResult.Converted) &&
                    !reservationRepository.GetAll().Any(r =>
                        !r.IsDeleted && !r.IsCanceled && r.LeadAssignmentId == x.Id));
            }

            var allLeads = leadsQuery
                .Select(x => new LeadsAssignmentItemsResponse()
                {
                    Id = x.Id,
                    SourceType = x.SourceType,
                    LeadAssignmentState = x.LeadAssignmentState,
                    leadAssignmentType = x.AssignmentType,
                    PhoneNumber = x.PhoneNumber,
                    UserName = x.UserName,
                    ConsultantProfileId = x.ConsultantProfile != null &&
                                          !x.ConsultantProfile.IsDeleted &&
                                          x.ConsultantProfile.IsCompleteProfile &&
                                          !x.ConsultantProfile.User.IsDeleted &&
                                          x.ConsultantProfile.User.IsActive
                        ? x.ConsultantProfileId
                        : null,
                    ConsultantFullName = x.ConsultantProfile == null
                        ? null
                        : x.ConsultantProfile.User.FirstName + " " + x.ConsultantProfile.User.LastName,
                    ConsultantPhoneNumber = x.ConsultantProfile == null
                        ? null
                        : x.ConsultantProfile.User.PhoneNumber,
                    CreatedAt = x.CreatedAt,
                    AssignedAt = x.AssignedAt,
                    ContactedAt = x.ContactedAt,
                    ReportSubmittedAt = x.ReportSubmittedAt,
                    ClosedByConsultantAt = x.ClosedByConsultantAt,
                    ClosureReason = x.ClosureReason,
                    ClosureDescription = x.ClosureDescription,
                });
            if (query.SourceType.HasValue)
                allLeads = allLeads.Where(x => x.SourceType == query.SourceType.Value);

            if (query.leadAssignmentState.HasValue)
            {
                allLeads = allLeads.Where(x => x.LeadAssignmentState == query.leadAssignmentState.Value);
            }
            if (query.LeadAssignmentType.HasValue)
            {
                allLeads = allLeads.Where(x => x.leadAssignmentType == query.LeadAssignmentType.Value);
            }

            if (!string.IsNullOrWhiteSpace(query.SearchText))
            {
                var searchText = query.SearchText.Trim();
                allLeads = allLeads.Where(x =>
                    x.UserName.Contains(searchText) || x.PhoneNumber.Contains(searchText));
            }

            return await LeadAssignmentPagination.ToUnpaginatedResultAsync(allLeads, cancellationToken);
        }
    }
}
