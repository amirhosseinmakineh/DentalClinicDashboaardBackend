using DentalDashboard.Domain.Enums;
using DentalDashboard.Domain.Models;
using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.Enums;

namespace DentalDashboard.Domain.Secretary.Accountant.PatientFinance.Entities;

public sealed class PatientFinancialCase : BaseAuditableEntity<Guid> {
  public Guid PatientId { get; set; }
  public List<DentalServiceType> Services { get; set; } = [];
  public int? ToothUnitCount { get; set; }
  public string ServiceUnitCountsJson { get; set; } = "{}";
  public decimal TotalAmount { get; set; }
  public decimal PrePaymentAmount { get; set; }
  public decimal DepositAmount { get; set; }
  public string? PaymentMethod { get; set; }
  public string? InstallmentStatus { get; set; }
  public string? GuaranteeDocument { get; set; }
  public DateTime? GuaranteeDate { get; set; }
  public decimal? GuaranteeAmount { get; set; }
  public string? GuaranteeChequeRegistration { get; set; }
  public string? Notes { get; set; }
  public string? OpgImageUrl { get; set; }
  public string? ConsultantName { get; set; }
  public string? ReviewItems { get; set; }
  public PatientFinancialAgreementType AgreementType { get; set; }
  public PatientFinancialCaseStatus Status {
    get; set;
  } = PatientFinancialCaseStatus.Active;
  public Guid CreatedByUserId { get; set; }
  public User Patient { get; set; } = default!;
  public User CreatedByUser { get; set; } = default!;
  public ICollection<PatientCheque> Cheques { get; set; } = [];
  public ICollection<PatientPromissoryNote> PromissoryNotes { get; set; } = [];
  public ICollection<PatientDebt> Debts { get; set; } = [];
  public ICollection<PatientFinancialTransaction> Transactions {
    get; set;
  } = [];
}

public sealed class PatientFinancialDocument : BaseAuditableEntity<Guid>
{
    public Guid PatientFinancialCaseId { get; set; }
    public string StoragePath { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public string? Description { get; set; }
    public PatientFinancialCase FinancialCase { get; set; } = default!;
}

public sealed class PatientCheque : BaseAuditableEntity<long> {
  public bool IsGuarantee { get; set; }
  public Guid PatientFinancialCaseId { get; set; }
  public decimal Amount { get; set; }
  public string SayadNumber { get; set; } = default!;
  public string OwnerName { get; set; } = default!;
  public DateTime DueDate { get; set; }
  public PatientChequeStatus Status { get; set; } = PatientChequeStatus.Pending;
  public PatientFinancialCase FinancialCase { get; set; } = default!;
}

public sealed class PatientPromissoryNote : BaseAuditableEntity<long> {
  public bool IsGuarantee { get; set; }
  public Guid PatientFinancialCaseId { get; set; }
  public string SerialNumber { get; set; } = default!;
  public decimal Amount { get; set; }
  public DateTime DueDate { get; set; }
  public PatientPromissoryNoteStatus Status {
    get; set;
  } = PatientPromissoryNoteStatus.Pending;
  public PatientFinancialCase FinancialCase { get; set; } = default!;
}

public sealed class PatientFinancialTransaction : BaseAuditableEntity<long> {
  public Guid PatientFinancialCaseId { get; set; }
  public decimal Amount { get; set; }
  public PatientFinancialTransactionType Type {
    get; set;
  } = PatientFinancialTransactionType.Payment;
  public PatientFinancialTransactionSourceType SourceType { get; set; }
  public long SourceId { get; set; }
  public Guid CreatedByUserId { get; set; }
  public PatientFinancialCase FinancialCase { get; set; } = default!;
  public User CreatedByUser { get; set; } = default!;
}

public sealed class PatientDebt : BaseAuditableEntity<long> {
  public Guid PatientFinancialCaseId { get; set; }
  public decimal Amount { get; set; }
  public PatientDebtSourceType SourceType { get; set; }
  public long SourceId { get; set; }
  public PatientDebtStatus Status { get; set; } = PatientDebtStatus.Unpaid;
  public DateTime DueDate { get; set; }
  public PatientFinancialCase FinancialCase { get; set; } = default!;
}
