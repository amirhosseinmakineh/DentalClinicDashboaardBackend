using DentalDashboard.ApplicationService.Contract.IServices;
using DentalDashboard.ApplicationService.Contract.Responses;
using DentalDashboard.ApplicationService.Contract.Responses.ReservationResponse;
using DentalDashboard.Domain.IRepositories;
using DentalDashboard.Utilities.Convertor;
using DentalDashboard.Utilities.Time;
using Microsoft.EntityFrameworkCore;

namespace DentalDashboard.ApplicationService.Handlers.QueryHandlers.Reservation
{
    public class GetSecretaryReservationsQueryHandler : IQueryHandler<GetSecretaryReservationsQuery, PaginatedResult<SecretaryReservationItemResponse>>
    {
        private readonly IReservationRepository reservationRepository;
        private readonly IUserRepository userRepository;
        private readonly ISecretaryAccessService secretaryAccessService;

        public GetSecretaryReservationsQueryHandler(
            IReservationRepository reservationRepository,
            IUserRepository userRepository,
            ISecretaryAccessService secretaryAccessService)
        {
            this.reservationRepository = reservationRepository;
            this.userRepository = userRepository;
            this.secretaryAccessService = secretaryAccessService;
        }

        public async Task<PaginatedResult<SecretaryReservationItemResponse>> HandleAsync(
            GetSecretaryReservationsQuery query,
            CancellationToken cancellationToken = default)
        {
            var pageNumber = Math.Max(query.PageNumber, 1);
            var pageSize = Math.Clamp(query.PageSize, 1, 100);

            if (!query.IsAdmin)
            {
                var access = await secretaryAccessService.GetAccessAsync(query.SecretaryUserId, cancellationToken);
                if (!access.IsSecretary)
                    return EmptyResult(pageNumber, pageSize);
            }

            var reservations = reservationRepository.GetAll()
                .AsNoTracking()
                .Where(x => !x.IsDeleted);

            // ------------------------------------------------------------
            // Basic filters
            // ------------------------------------------------------------

            if (query.PatientFileLeadAssignmentId.HasValue)
                reservations = reservations.Where(x => x.LeadAssignmentId == query.PatientFileLeadAssignmentId.Value);
            else if (!string.IsNullOrWhiteSpace(query.PatientFilePhoneNumber))
                reservations = reservations.Where(x => x.LeadAssignment.PhoneNumber == query.PatientFilePhoneNumber);

            if (!query.IncludeCanceled)
            {
                reservations = reservations.Where(x => !x.IsCanceled);
            }

            if (query.ConsultantProfileId.HasValue)
            {
                var consultantProfileId = query.ConsultantProfileId.Value;

                reservations = reservations.Where(x =>
                    x.ConsultantProfileId == consultantProfileId);
            }

            if (query.ReservationType.HasValue)
            {
                var reservationType = query.ReservationType.Value;

                reservations = reservations.Where(x =>
                    x.ReservationType == reservationType);
            }

            // ------------------------------------------------------------
            // Patient search
            // ------------------------------------------------------------

            var patientSearch = !string.IsNullOrWhiteSpace(query.Search)
                ? query.Search
                : query.SearchText;
            if (!string.IsNullOrWhiteSpace(patientSearch))
            {
                var search = patientSearch.Trim();

                reservations = reservations.Where(x =>
                    x.LeadAssignment.UserName.Contains(search) ||
                    x.LeadAssignment.PhoneNumber.Contains(search) ||
                    (
                        x.LeadAssignment.SecondaryPhoneNumber != null &&
                        x.LeadAssignment.SecondaryPhoneNumber.Contains(search)
                    ));
            }

            // ------------------------------------------------------------
            // Consultant search
            // ------------------------------------------------------------

            if (!string.IsNullOrWhiteSpace(query.ConsultantName))
            {
                var consultantName = query.ConsultantName.Trim();

                reservations = reservations.Where(x =>
                    x.ConsultantProfile.User.FirstName.Contains(consultantName) ||
                    x.ConsultantProfile.User.LastName.Contains(consultantName) ||
                    (
                        x.ConsultantProfile.User.FirstName + " " +
                        x.ConsultantProfile.User.LastName
                    ).Contains(consultantName));
            }

            // ------------------------------------------------------------
            // ReservationAt date range in Iran wall-clock time
            // ------------------------------------------------------------

            if (query.Date.HasValue)
            {
                var (start, _) = IranTimeHelper.GetIranLocalDayRange(query.Date.Value);
                var endExclusive = query.Date.Value.AddDays(1).ToDateTime(TimeOnly.MinValue);
                reservations = reservations.Where(x =>
                    x.ReservationAt >= start && x.ReservationAt < endExclusive);
            }

            var fromValue = query.FromDate ?? query.From;
            if (!query.Date.HasValue && fromValue.HasValue)
            {
                var fromDate = IranTimeHelper.GetDateInIran(fromValue.Value);
                var (start, _) = IranTimeHelper.GetIranLocalDayRange(fromDate);

                reservations = reservations.Where(x => x.ReservationAt >= start);
            }

            var toValue = query.ToDate ?? query.To;
            if (!query.Date.HasValue && toValue.HasValue)
            {
                var toDate = IranTimeHelper.GetDateInIran(toValue.Value);
                var toDateExclusive = toDate.AddDays(1).ToDateTime(TimeOnly.MinValue);

                reservations = reservations.Where(x => x.ReservationAt < toDateExclusive);
            }
            // ------------------------------------------------------------
            // Secretary announcement status
            // ------------------------------------------------------------

            if (query.SecretaryAnnouncementStatus.HasValue)
            {
                var status = query.SecretaryAnnouncementStatus.Value;

                reservations = reservations.Where(x =>
                    x.SecretaryAnnouncementStatus == status);
            }

            // ------------------------------------------------------------
            // Attendance status
            // ------------------------------------------------------------

            var attendanceStatus = query.AttendanceStatus ?? query.AttendanceConfirmationStatus;
            if (attendanceStatus.HasValue)
            {
                var status = attendanceStatus.Value;

                reservations = reservations.Where(x =>
                    x.AttendanceConfirmationStatus == status);
            }

            if (query.OnlyWaitingForSecretaryReview)
            {
                reservations = reservations.Where(x =>
                    x.SecretaryReviewedAt == null &&
                    (x.AttendanceConfirmationStatus == ReservationAttendanceConfirmationStatus.ConsultantConfirmedPresent ||
                     x.AttendanceConfirmationStatus == ReservationAttendanceConfirmationStatus.ConsultantConfirmedAbsent));
            }

            if (query.OnlyConsultantAttendanceConfirmed)
            {
                reservations = reservations.Where(x =>
                    x.AttendanceConfirmationStatus == ReservationAttendanceConfirmationStatus.ConsultantConfirmedPresent ||
                    x.AttendanceConfirmationStatus == ReservationAttendanceConfirmationStatus.ConsultantConfirmedAbsent);
            }

            if (query.OnlyDue)
                reservations = reservations.Where(x => x.ReservationAt <= IranTimeHelper.IranLocalNow);

            if (!string.IsNullOrWhiteSpace(query.ReservationStatus))
            {
                reservations = query.ReservationStatus.Trim().ToLowerInvariant() switch
                {
                    "pending" => reservations.Where(x =>
                        !x.IsCanceled &&
                        x.SecretaryReviewedAt == null),

                    "confirmed" => reservations.Where(x =>
                        !x.IsCanceled &&
                        x.SecretaryReviewedAt != null &&
                        x.SecretaryApprovedConsultantConfirmation == true),

                    "cancelled" => reservations.Where(x =>
                        x.IsCanceled),

                    _ => reservations
                };
            }

            // ------------------------------------------------------------
            // Count BEFORE paging
            // ------------------------------------------------------------

            var totalCount = await reservations.CountAsync(cancellationToken);

            if (totalCount == 0)
            {
                return EmptyResult(pageNumber, pageSize);
            }

            // ------------------------------------------------------------
            // Sorting
            // ------------------------------------------------------------

            reservations = query.SortDirection?.ToLowerInvariant() switch
            {
                "desc" => reservations
                    .OrderByDescending(x => x.ReservationAt)
                    .ThenByDescending(x => x.Id),

                _ => reservations
                    .OrderBy(x => x.ReservationAt)
                    .ThenBy(x => x.Id)
            };

            // ------------------------------------------------------------
            // Paging + Projection
            // ------------------------------------------------------------

            var items = await reservations
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new SecretaryReservationItemResponse
                {
                    Id = x.Id,
                    ReservationId = x.Id,

                    LeadAssignmentId = x.LeadAssignmentId,

                    ConsultantProfileId = x.ConsultantProfileId,
                    ConsultantUserId = x.ConsultantProfile.UserId,

                    ConsultantFullName =
                        x.ConsultantProfile.User.FirstName + " " +
                        x.ConsultantProfile.User.LastName,

                    PatientUserId = x.PatientUserId,
                    RequiresPatientProfile = !x.PatientUserId.HasValue,

                    ReservationAt = x.ReservationAt,
                    AppointmentDateTime = x.ReservationAt,
                    PatientCount = x.PatientCount,
                    CreatedAt = x.CreatedAt,

                    ReservationType = x.ReservationType,

                    PatientReceivedService = x.PatientReceivedService,

                    PatientName = x.LeadAssignment.UserName,
                    PatientPhoneNumber = x.LeadAssignment.PhoneNumber,
                    SecondaryPhoneNumber =
                        x.LeadAssignment.SecondaryPhoneNumber,

                    PatientCity =
                        x.LeadAssignment.PatientCity ?? string.Empty,

                    PatientRegion =
                        x.LeadAssignment.PatientRegion,

                    BusinessName =
                        x.LeadAssignment.BusinessName,

                    AttendanceProbabilityPercent =
                        x.LeadAssignment.AttendanceProbabilityPercent,

                    AttendanceConfirmationStatus =
                        x.AttendanceConfirmationStatus,

                    ConsultantAttendanceConfirmedAt =
                        x.ConsultantAttendanceConfirmedAt,

                    ConsultantSaysPatientAttended =
                        x.ConsultantSaysPatientAttended,

                    ConsultantAttendanceNote =
                        x.ConsultantAttendanceNote,

                    IsWaitingForSecretaryReview =
                        x.SecretaryReviewedAt == null &&
                        (
                            x.AttendanceConfirmationStatus ==
                                ReservationAttendanceConfirmationStatus
                                    .ConsultantConfirmedPresent
                            ||
                            x.AttendanceConfirmationStatus ==
                                ReservationAttendanceConfirmationStatus
                                    .ConsultantConfirmedAbsent
                        ),

                    SecretaryReviewedAt =
                        x.SecretaryReviewedAt,

                    SecretaryUserId =
                        x.SecretaryUserId,

                    SecretaryApprovedConsultantConfirmation =
                        x.SecretaryApprovedConsultantConfirmation,

                    SecretaryReviewNote =
                        x.SecretaryReviewNote,

                    SecretaryAnnouncementStatus =
                        x.SecretaryAnnouncementStatus,

                    SecretaryAnnouncement =
                        x.SecretaryAnnouncement,

                    SecretaryAnnouncementUpdatedAt =
                        x.SecretaryAnnouncementUpdatedAt,

                    SecretaryAnnouncementUserId =
                        x.SecretaryAnnouncementUserId,

                    IsAttendanceScoreApplied =
                        x.IsAttendanceScoreApplied,

                    AttendanceScoreValue =
                        x.AttendanceScoreValue,

                    AttendanceScoreAppliedAt =
                        x.AttendanceScoreAppliedAt,

                    Description =
                        x.Description,

                    DoctorName =
                        x.DoctorName,

                    IsCanceled =
                        x.IsCanceled,

                    DentalServices =
                        x.DentalServices
                })
                .ToListAsync(cancellationToken);

            // ------------------------------------------------------------
            // Non-database formatting
            // ------------------------------------------------------------

            foreach (var item in items)
            {
                item.ReservationAtPersian =
                    item.ReservationAt.ToPersianDateTimeString();

                item.CreatedAtPersian =
                    item.CreatedAt.ToPersianDateTimeString();

                item.SecretaryReviewedAtPersian =
                    item.SecretaryReviewedAt?.ToPersianDateTimeString();
            }

            return new PaginatedResult<SecretaryReservationItemResponse>
            {
                Items = items,
                TotalCount = totalCount,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }

        private static PaginatedResult<SecretaryReservationItemResponse> EmptyResult(
            int pageNumber,
            int pageSize)
        {
            return new PaginatedResult<SecretaryReservationItemResponse>
            {
                Items = [],
                TotalCount = 0,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }
    }
}
