using DentalDashboard.Domain.Enums;

namespace DentalDashboard.ApplicationService.Contract.Responses.LeadResponse
{
    public record LeadsAssignmentItemsResponse : BaseResponse<long>
    {
        public long LeadAssignmentId => Id;
        public LeadSourceType SourceType { get; set; }
        public string UserName { get; set; } = default!;
        public string FullName => UserName;
        public string PhoneNumber { get; set; } = default!;
        public long? ConsultantProfileId { get; set; }
        public string? ConsultantFullName { get; set; }
        public string? ConsultantPhoneNumber { get; set; }
        public DateTime CreatedAt { get; set; }
        public LeadAssignmentState LeadAssignmentState { get; set; }
        public LeadAssignmentType leadAssignmentType { get; set; }
        public bool HasActiveReservation { get; set; }
        public DateTime? AssignedAt { get; set; }
        public DateTime? CallDeadlineAt { get; set; }
        public bool RequiresThreeMinuteCall { get; set; }
        public bool IsReportSubmitted { get; set; }
        public DateTime? ReportSubmittedAt { get; set; }
        public DateTime? ContactedAt { get; set; }
        public DateTime? CallInitiatedAt { get; set; }
        public LeadCallResult? CallResult { get; set; }
        public string? ReportDescription { get; set; }
        public string? PatientCity { get; set; }
        public string? PatientRegion { get; set; }
        public string? BusinessName { get; set; }
        public int? AttendanceProbabilityPercent { get; set; }
        public string? SecondaryPhoneNumber { get; set; }
        public DateTime? ClosedByConsultantAt { get; set; }
        public LeadClosureReason? ClosureReason { get; set; }
        public string? ClosureDescription { get; set; }
    }
}
