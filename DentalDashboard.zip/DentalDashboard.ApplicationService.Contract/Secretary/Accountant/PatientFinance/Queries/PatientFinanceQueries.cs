using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.Enums;
using DentalDashboard.Framwork.Cqrs.Abstraction.Read;
using DentalDashboard.Domain.Models;

namespace DentalDashboard.ApplicationService.Contract.Secretary.Accountant.PatientFinance
    .Queries;

public abstract class PatientFinancePagedQuery {
  public int Page { get; set; } = 1;
  public int PageSize { get; set; } = 20;
}
public sealed class GetPatientFinancialCasesQuery
    : PatientFinancePagedQuery,
      IQuery<PaginatedResult<PatientFinancialCaseDto>> {
  public string? Search { get; set; }
  public Guid? PatientId { get; set; }
  public List<int>? ServiceIds { get; set; }
  public PatientFinancialAgreementType? AgreementType { get; set; }
  public PatientFinancialCaseStatus? Status { get; set; }
  public DateTime? FromDate { get; set; }
  public DateTime? ToDate { get; set; }
}
public sealed
    record GetPatientFinancialCaseDetailsQuery(Guid PatientFinancialCaseId)
    : IQuery<PatientFinancialCaseDetailsDto?>;
public sealed record GetPatientFinancialCaseSummaryQuery(Guid PatientFinancialCaseId): IQuery<PatientFinancialCaseSummaryDto?>;
public sealed record GetPatientFinancialSummaryQuery(Guid PatientId)
    : IQuery<PatientFinancialSummaryDto?>;
public sealed class GetPatientChequesQuery
    : PatientFinancePagedQuery,
      IQuery<PaginatedResult<PatientChequeDto>> {
  public Guid? PatientFinancialCaseId { get; set; }
  public Guid? PatientId { get; set; }
  public string? Search { get; set; }
  public PatientChequeStatus? Status { get; set; }
  public DateTime? FromDueDate { get; set; }
  public DateTime? ToDueDate { get; set; }
}
public sealed class GetPatientPromissoryNotesQuery
    : PatientFinancePagedQuery,
      IQuery<PaginatedResult<PatientPromissoryNoteDto>> {
  public Guid? PatientFinancialCaseId { get; set; }
  public Guid? PatientId { get; set; }
  public string? Search { get; set; }
  public PatientPromissoryNoteStatus? Status { get; set; }
  public DateTime? FromDueDate { get; set; }
  public DateTime? ToDueDate { get; set; }
}
public sealed class GetPatientDebtsQuery
    : PatientFinancePagedQuery,
      IQuery<PaginatedResult<PatientDebtDto>> {
  public Guid? PatientId { get; set; }
  public Guid? PatientFinancialCaseId { get; set; }
  public PatientDebtSourceType? SourceType { get; set; }
  public PatientDebtStatus? Status { get; set; }
  public int? Year { get; set; }
  public int? Month { get; set; }
  public DateTime? FromDueDate { get; set; }
  public DateTime? ToDueDate { get; set; }
  public string? Search { get; set; }
}
public sealed class GetPatientFinancialTransactionsQuery
    : PatientFinancePagedQuery,
      IQuery<PaginatedResult<PatientFinancialTransactionDto>> {
  public Guid? PatientId { get; set; }
  public Guid? PatientFinancialCaseId { get; set; }
  public PatientFinancialTransactionSourceType? SourceType { get; set; }
  public DateTime? FromDate { get; set; }
  public DateTime? ToDate { get; set; }
}
public sealed class GetDuePatientFinancialCommitmentsQuery
    : PatientFinancePagedQuery,
      IQuery<PaginatedResult<PatientFinancialCommitmentDto>> {
  public DateTime? FromDate { get; set; }
  public DateTime? ToDate { get; set; }
  public PatientFinancialCommitmentType? Type { get; set; }
  public Guid? PatientId { get; set; }
}

public sealed record PatientFinancialCaseDto(
    Guid Id, Guid PatientId, Guid UserId, string PatientName,
    string PatientFileNumber, string? PatientPhoneNumber, List<int> ServiceIds, List<string> ServiceNames, decimal TotalAmount,
    decimal PrePaymentAmount, decimal DepositAmount,
    decimal TotalPaidAmount, decimal RemainingAmount, decimal TotalDebtAmount,
    PatientFinancialAgreementType AgreementType,
    PatientFinancialCaseStatus Status, DateTime CreatedAt)
{
    public decimal BalanceAmount { get; init; }
    public string? PaymentMethod { get; init; }
    public string? InstallmentStatus { get; init; }
    public string? GuaranteeDocument { get; init; }
    public string? Notes { get; init; }
    public string? OpgImageUrl { get; init; }
    public string? ConsultantName { get; init; }
    public int? ToothUnitCount { get; init; }
    public string ServiceUnitCountsJson { get; init; } = "{}";
    public IReadOnlyList<DateTime> ChequeDates { get; init; } = [];
    public IReadOnlyList<string> ChequeRegistrations { get; init; } = [];
}
public sealed record PatientFinancialCaseDetailsDto(
    PatientFinancialCaseDto Case, int ChequeCount, decimal ChequeAmount,
    int PromissoryNoteCount, decimal PromissoryNoteAmount,
    IReadOnlyList<PatientChequeDto> Cheques,
    IReadOnlyList<PatientPromissoryNoteDto> PromissoryNotes);
public sealed record PatientChequeDto(long Id, Guid PatientFinancialCaseId,
                                      Guid PatientId, string PatientName,
                                      string PatientFileNumber,
                                      decimal Amount, string SayadNumber,
                                      string OwnerName, DateTime DueDate,
                                      PatientChequeStatus Status, bool IsGuarantee);
public sealed record PatientPromissoryNoteDto(
    long Id, Guid PatientFinancialCaseId, Guid PatientId, string PatientName,
    string PatientFileNumber,
    string SerialNumber, decimal Amount, DateTime DueDate,
    PatientPromissoryNoteStatus Status, bool IsGuarantee = false);
public sealed record PatientDebtDto(long Id, Guid PatientId, string PatientName,
                                    string PatientFileNumber,
                                    string? PatientPhoneNumber,
                                    Guid PatientFinancialCaseId,
                                    List<string> ServiceNames, decimal Amount,
                                    PatientDebtSourceType SourceType,
                                    long SourceId, DateTime DueDate,
                                    PatientDebtStatus Status);
public sealed record PatientFinancialTransactionDto(
    long Id, Guid PatientFinancialCaseId, Guid PatientId, string PatientName,
    string PatientFileNumber, decimal Amount,
    PatientFinancialTransactionType Type,
    PatientFinancialTransactionSourceType SourceType, long SourceId,
    DateTime CreatedAt);
public sealed record PatientFinancialSummaryDto(
    Guid PatientId, decimal TotalTreatmentAmount, decimal TotalPaidAmount,
    decimal RemainingAmount, decimal TotalDebtAmount,
    int ActiveFinancialCasesCount, int UnpaidChequesCount,
    int UnpaidPromissoryNotesCount);
public sealed record PatientFinancialCaseSummaryDto(
    decimal TotalAmount, decimal TotalPaidAmount, decimal RemainingAmount,
    decimal TotalChequeAmount, decimal PaidChequeAmount,
    decimal PendingChequeAmount, decimal UnpaidChequeAmount,
    decimal TotalPromissoryNoteAmount, decimal PaidPromissoryNoteAmount,
    decimal PendingPromissoryNoteAmount, decimal UnpaidPromissoryNoteAmount,
    decimal TotalDebtAmount);
public sealed record PatientFinancialCommitmentDto(
    long Id, PatientFinancialCommitmentType Type, Guid PatientFinancialCaseId,
    Guid PatientId, string PatientName, string PatientFileNumber,
    decimal Amount, DateTime DueDate,
    int Status);
