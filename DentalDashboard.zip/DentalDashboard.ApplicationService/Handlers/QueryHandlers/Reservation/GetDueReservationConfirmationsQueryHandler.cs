using DentalDashboard.ApplicationService.Contract.Requests.Reservation.Queries;
using DentalDashboard.ApplicationService.Contract.Responses.ReservationResponse;
using DentalDashboard.Domain.IRepositories;
using DentalDashboard.Framwork.Cqrs.Abstraction.Read;
using Microsoft.EntityFrameworkCore;

namespace DentalDashboard.ApplicationService.Handlers.QueryHandlers.Reservation
{
    public class GetDueReservationConfirmationsQueryHandler : IQueryHandler<GetDueReservationConfirmationsQuery, List<ReservationItemResponse>>
    {
        private readonly IReservationRepository reservationRepository;

        public GetDueReservationConfirmationsQueryHandler(IReservationRepository reservationRepository)
        {
            this.reservationRepository = reservationRepository;
        }

        public async Task<List<ReservationItemResponse>> HandleAsync(GetDueReservationConfirmationsQuery query, CancellationToken cancellationToken = default)
        {
            var now = query.Now ?? DateTime.Now;

            var reservations = reservationRepository.GetAll()
                .Where(x => x.ConsultantProfileId == query.ConsultantProfileId &&
                            !x.IsCanceled &&
                            x.ReservationAt <= now &&
                            x.AttendanceConfirmationStatus == ReservationAttendanceConfirmationStatus.PendingConsultantConfirmation);

            if (query.FromDate.HasValue)
            {
                var from = query.FromDate.Value.ToDateTime(TimeOnly.MinValue);
                reservations = reservations.Where(x => x.ReservationAt >= from);
            }
            if (query.ToDate.HasValue && query.ToDate.Value < DateOnly.MaxValue)
            {
                var toExclusive = query.ToDate.Value.AddDays(1).ToDateTime(TimeOnly.MinValue);
                reservations = reservations.Where(x => x.ReservationAt < toExclusive);
            }

            return await reservations
                .OrderBy(x => x.ReservationAt)
                .Select(x => new ReservationItemResponse
                {
                    Id = x.Id,
                    ReservationId = x.Id,
                    LeadAssignmentId = x.LeadAssignmentId,
                    ConsultantProfileId = x.ConsultantProfileId,
                    PatientUserId = x.PatientUserId,
                    RequiresPatientProfile = !x.PatientUserId.HasValue,
                    ReservationAt = x.ReservationAt,
                    AppointmentDateTime = x.ReservationAt,
                    PatientCount = x.PatientCount,
                    CreatedAt = x.CreatedAt,
                    PatientName = x.LeadAssignment != null ? x.LeadAssignment.UserName : string.Empty,
                    PatientPhoneNumber = x.LeadAssignment != null ? x.LeadAssignment.PhoneNumber : string.Empty,
                    SecondaryPhoneNumber = x.LeadAssignment != null ? x.LeadAssignment.SecondaryPhoneNumber : null,
                    PatientCity = x.LeadAssignment != null ? (x.LeadAssignment.PatientCity ?? string.Empty) : string.Empty,
                    PatientRegion = x.LeadAssignment != null ? x.LeadAssignment.PatientRegion : null,
                    BusinessName = x.LeadAssignment != null ? x.LeadAssignment.BusinessName : null,
                    AttendanceProbabilityPercent = x.LeadAssignment != null ? x.LeadAssignment.AttendanceProbabilityPercent : null,
                    AttendancePrediction = x.AttendancePrediction,
                    SecretaryAnnouncementStatus = x.SecretaryAnnouncementStatus,
                    SecretaryAnnouncement = x.SecretaryAnnouncement,
                    SecretaryAnnouncementUpdatedAt = x.SecretaryAnnouncementUpdatedAt,
                    SecretaryAnnouncementUserId = x.SecretaryAnnouncementUserId,
                    AttendanceConfirmationStatus = x.AttendanceConfirmationStatus,
                    IsDueForConsultantConfirmation = true,
                    Description = x.Description,
                    DoctorName = x.DoctorName,
                    IsCanceled = x.IsCanceled
                })
                .ToListAsync(cancellationToken);
        }
    }
}
