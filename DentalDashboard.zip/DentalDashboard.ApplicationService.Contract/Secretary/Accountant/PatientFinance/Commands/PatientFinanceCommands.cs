using System.Text.Json.Serialization;
using System.Text.Json;
using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.Enums;
using DentalDashboard.Framwork.Cqrs.Abstraction.Wrire;

namespace DentalDashboard.ApplicationService.Contract.Secretary.Accountant.PatientFinance
    .Commands;

public sealed record CreatePatientChequeDto(decimal Amount, string SayadNumber,
                                            string OwnerName, DateTime DueDate, bool IsGuarantee = false);
public sealed record CreatePatientPromissoryNoteDto(string SerialNumber,
                                                    decimal Amount,
                                                    DateTime DueDate);
public sealed record PatientFinanceIdResponse(long Id);
public sealed record PatientFinancialCaseIdResponse(Guid Id);
public sealed record GuaranteeDocumentResponse(Guid Id, string? GuaranteeDocument);
public sealed record UploadGuaranteeDocumentCommand(Guid CaseId, string FilePath)
    : ICommand<GuaranteeDocumentResponse>;

public sealed class CreatePatientFinancialCaseCommand
    : ICommand<PatientFinancialCaseIdResponse> {
  public Guid PatientId { get; set; }
  public List<int> ServiceIds { get; set; } = [];
  public int? ToothUnitCount { get; set; }
  public Dictionary<int, int>? ServiceUnitCounts { get; set; }
  public decimal TotalAmount { get; set; }
  public decimal PrePaymentAmount { get; set; }
  public decimal DepositAmount { get; set; }
  public string? PaymentMethod { get; set; }
  public string? InstallmentStatus { get; set; }
  public string? GuaranteeDocument { get; set; }
  public string? Notes { get; set; }
  public string? OpgImageUrl { get; set; }
  public string? ConsultantName { get; set; }
  public PatientFinancialAgreementType AgreementType { get; set; }
  public List<CreatePatientChequeDto>? Cheques { get; set; }
  public List<CreatePatientPromissoryNoteDto>? PromissoryNotes { get; set; }
  [JsonIgnore]
  public Guid ActorUserId {
    get; set;
  }
}
public sealed class UpdatePatientFinancialCaseCommand
    : ICommand<PatientFinancialCaseIdResponse> {
  [JsonIgnore]
  public Guid Id { get; set; }
  public int? ToothUnitCount { get; set; }
  public Dictionary<int, int>? ServiceUnitCounts { get; set; }
  public decimal TotalAmount { get; set; }
  public decimal PrePaymentAmount { get; set; }
  public decimal DepositAmount { get; set; }
  public string? PaymentMethod { get; set; }
  public string? InstallmentStatus { get; set; }
  public string? GuaranteeDocument { get; set; }
  public string? Notes { get; set; }
  public string? OpgImageUrl { get; set; }
  public string? ConsultantName { get; set; }
  public PatientFinancialAgreementType AgreementType { get; set; }
}
public sealed record CancelPatientFinancialCaseCommand(Guid Id)
    : ICommand<PatientFinancialCaseIdResponse>;
public sealed record AddPatientChequeCommand(Guid PatientFinancialCaseId,
                                             decimal Amount, string SayadNumber,
                                             string OwnerName, DateTime DueDate, bool IsGuarantee = false)
    : ICommand<PatientFinanceIdResponse>;
public sealed
    record AddPatientPromissoryNoteCommand(Guid PatientFinancialCaseId,
                                           string SerialNumber, decimal Amount,
                                           DateTime DueDate)
    : ICommand<PatientFinanceIdResponse>;
public sealed class UpdatePatientChequeStatusCommand
    : ICommand<PatientFinanceIdResponse> {
  [JsonIgnore]
  public long ChequeId { get; set; }
  public PatientChequeStatus Status { get; set; }
  [JsonIgnore]
  public Guid ActorUserId {
    get; set;
  }
}
public sealed class UpdatePatientChequeCommand
    : ICommand<PatientFinanceIdResponse> {
  [JsonIgnore]
  public long ChequeId { get; set; }
  public decimal Amount { get; set; }
  public string SayadNumber { get; set; } = string.Empty;
  public string OwnerName { get; set; } = string.Empty;
  public DateTime DueDate { get; set; }
  public bool IsGuarantee { get; set; }
  [JsonExtensionData]
  public Dictionary<string, JsonElement>? AdditionalFields { get; set; }
}
public sealed class UpdatePatientPromissoryNoteCommand
    : ICommand<PatientFinanceIdResponse> {
  [JsonIgnore]
  public long PromissoryNoteId { get; set; }
  public decimal Amount { get; set; }
  public string SerialNumber { get; set; } = string.Empty;
  public DateTime DueDate { get; set; }
  [JsonExtensionData]
  public Dictionary<string, JsonElement>? AdditionalFields { get; set; }
}
public sealed record DeletePatientChequeCommand(long ChequeId)
    : ICommand<PatientFinanceIdResponse>;
public sealed record DeletePatientPromissoryNoteCommand(long PromissoryNoteId)
    : ICommand<PatientFinanceIdResponse>;
public sealed class UpdatePatientPromissoryNoteStatusCommand
    : ICommand<PatientFinanceIdResponse> {
  [JsonIgnore]
  public long PromissoryNoteId { get; set; }
  public PatientPromissoryNoteStatus Status { get; set; }
  [JsonIgnore]
  public Guid ActorUserId {
    get; set;
  }
}
public sealed class PayPatientDebtCommand : ICommand<PatientFinanceIdResponse> {
  [JsonIgnore]
  public long DebtId { get; set; }
  [JsonIgnore]
  public Guid ActorUserId {
    get; set;
  }
}
