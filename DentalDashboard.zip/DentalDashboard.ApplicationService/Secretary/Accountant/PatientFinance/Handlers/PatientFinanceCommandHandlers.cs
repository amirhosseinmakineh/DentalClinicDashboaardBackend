using DentalDashboard.ApplicationService.Contract.IServices;
using DentalDashboard.ApplicationService.Contract.Secretary.Accountant.PatientFinance
    .Commands;
using DentalDashboard.Domain.Enums;
using DentalDashboard.Domain.IRepositories;
using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.Entities;
using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.Enums;
using DentalDashboard.Domain.Secretary.Accountant.PatientFinance.IRepositories;
using DentalDashboard.Framwork.Cqrs.Abstraction.Wrire;
using DentalDashboard.Framwork.Domain;
using Microsoft.EntityFrameworkCore;
using DentalDashboard.Utilities.Time;
using System.Data;

namespace DentalDashboard.ApplicationService.Secretary.Accountant.PatientFinance.Handlers;

internal static class ServiceUnitCountRules
{
    public static string? Validate(
        IReadOnlyDictionary<int, int>? counts,
        IReadOnlyCollection<int> selectedServices)
    {
        if (counts is null || counts.Count == 0)
        {
            return "تعداد واحد برای هر خدمت انتخاب‌شده الزامی است";
        }

        if (counts.Count != selectedServices.Count ||
            counts.Keys.Any(id => !selectedServices.Contains(id)))
        {
            return "تعداد واحد باید فقط برای تمام خدمات انتخاب‌شده ثبت شود";
        }

        if (counts.Values.Any(count => count < 1 || count > 100))
        {
            return "تعداد واحد هر خدمت باید بین ۱ تا ۱۰۰ باشد";
        }

        return null;
    }

    public static string Serialize(IReadOnlyDictionary<int, int> counts)
    {
        return System.Text.Json.JsonSerializer.Serialize(counts);
    }
}

internal static class FinanceRules {
  private const string PastDueDateMessage =
      "تاریخ سررسید چک یا سفته نمی‌تواند قبل از امروز باشد.";

  private static bool IsPastDueDate(DateTime due) =>
      IranTimeHelper.GetDateInIran(due) < IranTimeHelper.TodayInIran();

  public static string? Cheque(decimal amount, string? sayad, string? owner,
                               DateTime due) =>
      amount <= 0                        ? "مبلغ چک باید بیشتر از صفر باشد"
      : string.IsNullOrWhiteSpace(sayad) ? "شماره صیاد الزامی است"
      : string.IsNullOrWhiteSpace(owner) ? "نام صاحب چک الزامی است"
      : due == default                   ? "تاریخ سررسید الزامی است"
      : IsPastDueDate(due)               ? PastDueDateMessage
                                         : null;
  public static string? Note(decimal amount, string? serial, DateTime due) =>
      amount <= 0                         ? "مبلغ سفته باید بیشتر از صفر باشد"
      : string.IsNullOrWhiteSpace(serial) ? "شماره سریال سفته الزامی است"
      : due == default                    ? "تاریخ سررسید الزامی است"
      : IsPastDueDate(due)                ? PastDueDateMessage
                                          : null;
}

public sealed class CreatePatientFinancialCaseCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<CreatePatientFinancialCaseCommand,
                      PatientFinancialCaseIdResponse> {
  public async Task<Result<PatientFinancialCaseIdResponse>>
  HandleAsync(CreatePatientFinancialCaseCommand c,
              CancellationToken ct = default) {
    if (c.ActorUserId == Guid.Empty)
      return Result<PatientFinancialCaseIdResponse>.Failure("کاربر معتبر نیست");
    if (c.TotalAmount <= 0)
      return Result<PatientFinancialCaseIdResponse>.Failure(
          "مبلغ کل باید بیشتر از صفر باشد");
    if (c.PrePaymentAmount < 0 || c.DepositAmount < 0 ||
        c.PrePaymentAmount + c.DepositAmount > c.TotalAmount)
      return Result<PatientFinancialCaseIdResponse>.Failure(
          "مبلغ پیش‌پرداخت یا ودیعه معتبر نیست");
    if (!Enum.IsDefined(c.AgreementType))
      return Result<PatientFinancialCaseIdResponse>.Failure("نوع توافق معتبر نیست");
    if (c.ServiceIds is not { Count: > 0 })
      return Result<PatientFinancialCaseIdResponse>.Failure("حداقل یک خدمت الزامی است");
    if (c.ServiceIds.Any(id => !Enum.IsDefined(typeof(DentalServiceType), id)))
      return Result<PatientFinancialCaseIdResponse>.Failure("خدمت معتبر نیست");
    if (c.PatientId == Guid.Empty)
      return Result<PatientFinancialCaseIdResponse>.Failure("بیمار معتبر نیست");
    var serviceUnitError = ServiceUnitCountRules.Validate(
        c.ServiceUnitCounts,
        c.ServiceIds);
    if (serviceUnitError is not null)
    {
        return Result<PatientFinancialCaseIdResponse>.Failure(serviceUnitError);
    }

    var patient = await repo.Patients.AsNoTracking()
        .Where(x => !x.IsDeleted && x.Id == c.PatientId &&
                    x.PatientProfile != null && !x.PatientProfile.IsDeleted)
        .Select(x => new { x.Id })
        .SingleOrDefaultAsync(ct);
    if (patient is null)
      return Result<PatientFinancialCaseIdResponse>.Failure("بیمار معتبر نیست");
    var cheques = c.Cheques ?? [];
    var notes = c.PromissoryNotes ?? [];
    if (c.AgreementType == PatientFinancialAgreementType.PrePayment &&
        cheques.Count == 0 && notes.Count == 0)
      return Result<PatientFinancialCaseIdResponse>.Failure(
          "برای پیش‌پرداخت ثبت حداقل یک چک یا سفته الزامی " +
          "است");
    foreach (var x in cheques) {
      var e =
          FinanceRules.Cheque(x.Amount, x.SayadNumber, x.OwnerName, x.DueDate);
      if (e != null)
        return Result<PatientFinancialCaseIdResponse>.Failure(e);
    }
    foreach (var x in notes) {
      var e = FinanceRules.Note(x.Amount, x.SerialNumber, x.DueDate);
      if (e != null)
        return Result<PatientFinancialCaseIdResponse>.Failure(e);
    }
    var entity = new PatientFinancialCase {
      PatientId = patient.Id, Services = c.ServiceIds.Select(id => (DentalServiceType)id).ToList(),
      TotalAmount = c.TotalAmount, PrePaymentAmount = c.PrePaymentAmount,
      DepositAmount = c.DepositAmount, AgreementType = c.AgreementType,
      Status = c.PrePaymentAmount + c.DepositAmount >= c.TotalAmount
          ? PatientFinancialCaseStatus.Completed
          : PatientFinancialCaseStatus.Active,
      CreatedByUserId = c.ActorUserId,
      PaymentMethod = c.PaymentMethod,
      InstallmentStatus = c.InstallmentStatus,
      GuaranteeDocument = c.GuaranteeDocument,
      Notes = c.Notes,
      OpgImageUrl = c.OpgImageUrl,
      ConsultantName = c.ConsultantName,
      ToothUnitCount = c.ServiceUnitCounts!.Values.Sum(),
      ServiceUnitCountsJson = ServiceUnitCountRules.Serialize(
          c.ServiceUnitCounts)
    };
    foreach (var x in cheques)
      entity.Cheques.Add(new PatientCheque { Amount = x.Amount,
                                             SayadNumber = x.SayadNumber.Trim(),
                                             OwnerName = x.OwnerName.Trim(),
                                             DueDate = x.DueDate, IsGuarantee = x.IsGuarantee });
    foreach (var x in notes)
      entity.PromissoryNotes.Add(
          new PatientPromissoryNote { Amount = x.Amount,
                                      SerialNumber = x.SerialNumber.Trim(),
                                      DueDate = x.DueDate });
    await repo.AddCaseAsync(entity, ct);
    await uow.SaveChangesAsync();
    return Result<PatientFinancialCaseIdResponse>.Success(new(entity.Id));
  }
}
public sealed class AddPatientChequeCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<AddPatientChequeCommand, PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>>
  HandleAsync(AddPatientChequeCommand c, CancellationToken ct = default) {
    var e =
        FinanceRules.Cheque(c.Amount, c.SayadNumber, c.OwnerName, c.DueDate);
    if (e != null)
      return Result<PatientFinanceIdResponse>.Failure(e);
    if (!await repo.Cases.AnyAsync(x => x.Id == c.PatientFinancialCaseId &&
                                        x.Status ==
                                            PatientFinancialCaseStatus.Active,
                                   ct))
      return Result<PatientFinanceIdResponse>.Failure("پرونده فعال یافت نشد");
    var x = new PatientCheque {
      PatientFinancialCaseId = c.PatientFinancialCaseId, Amount = c.Amount,
      SayadNumber = c.SayadNumber.Trim(), OwnerName = c.OwnerName.Trim(),
      DueDate = c.DueDate,
      IsGuarantee = c.IsGuarantee
    };
    await repo.AddChequeAsync(x, ct);
    await uow.SaveChangesAsync();
    return Result<PatientFinanceIdResponse>.Success(new(x.Id));
  }
}
public sealed class AddPatientPromissoryNoteCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<AddPatientPromissoryNoteCommand,
                      PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>>
  HandleAsync(AddPatientPromissoryNoteCommand c,
              CancellationToken ct = default) {
    var e = FinanceRules.Note(c.Amount, c.SerialNumber, c.DueDate);
    if (e != null)
      return Result<PatientFinanceIdResponse>.Failure(e);
    if (!await repo.Cases.AnyAsync(x => x.Id == c.PatientFinancialCaseId &&
                                        x.Status ==
                                            PatientFinancialCaseStatus.Active,
                                   ct))
      return Result<PatientFinanceIdResponse>.Failure("پرونده فعال یافت نشد");
    var x = new PatientPromissoryNote {
      PatientFinancialCaseId = c.PatientFinancialCaseId, Amount = c.Amount,
      SerialNumber = c.SerialNumber.Trim(), DueDate = c.DueDate
    };
    await repo.AddPromissoryNoteAsync(x, ct);
    await uow.SaveChangesAsync();
    return Result<PatientFinanceIdResponse>.Success(new(x.Id));
  }
}
public sealed class UpdatePatientFinancialCaseCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<UpdatePatientFinancialCaseCommand,
                      PatientFinancialCaseIdResponse> {
  public async Task<Result<PatientFinancialCaseIdResponse>>
  HandleAsync(UpdatePatientFinancialCaseCommand c,
              CancellationToken ct = default) {
    var x = await repo.Cases.FirstOrDefaultAsync(x => x.Id == c.Id, ct);
    if (x is null)
      return Result<PatientFinancialCaseIdResponse>.Failure("پرونده یافت نشد");
    if (x.Status == PatientFinancialCaseStatus.Cancelled)
      return Result<PatientFinancialCaseIdResponse>.Failure(
          "پرونده لغوشده قابل ویرایش نیست");
    var paid = await repo.Transactions
        .Where(transaction => transaction.PatientFinancialCaseId == c.Id &&
                              transaction.Type == PatientFinancialTransactionType.Payment)
        .SumAsync(transaction => (decimal?)transaction.Amount, ct) ?? 0;
    var commitments = (await repo.Cheques
        .Where(item => item.PatientFinancialCaseId == c.Id && !item.IsGuarantee)
        .SumAsync(item => (decimal?)item.Amount, ct) ?? 0) +
        (await repo.PromissoryNotes
        .Where(item => item.PatientFinancialCaseId == c.Id && !item.IsGuarantee)
        .SumAsync(item => (decimal?)item.Amount, ct) ?? 0);
    if (c.TotalAmount <= 0 || c.TotalAmount < paid)
      return Result<PatientFinancialCaseIdResponse>.Failure(
          "مبلغ کل نمی‌تواند کمتر از پرداخت قطعی " +
          "باشد");
    if (c.PrePaymentAmount < 0 || c.DepositAmount < 0 ||
        c.PrePaymentAmount + c.DepositAmount + paid > c.TotalAmount)
      return Result<PatientFinancialCaseIdResponse>.Failure(
          "مبلغ پیش‌پرداخت یا ودیعه معتبر نیست");
    if (commitments > c.TotalAmount)
      return Result<PatientFinancialCaseIdResponse>.Failure(
          "مبلغ کل نمی‌تواند کمتر از مجموع چک‌ها و سفته‌ها باشد");
    var selectedServiceIds = x.Services.Select(service => (int)service).ToList();
    var serviceUnitError = ServiceUnitCountRules.Validate(
        c.ServiceUnitCounts,
        selectedServiceIds);
    if (serviceUnitError is not null)
    {
        return Result<PatientFinancialCaseIdResponse>.Failure(serviceUnitError);
    }

    x.ServiceUnitCountsJson = ServiceUnitCountRules.Serialize(c.ServiceUnitCounts!);
    x.TotalAmount = c.TotalAmount;
    x.PrePaymentAmount = c.PrePaymentAmount;
    x.DepositAmount = c.DepositAmount;
    x.AgreementType = c.AgreementType;
    x.PaymentMethod = c.PaymentMethod;
    x.InstallmentStatus = c.InstallmentStatus;
    x.GuaranteeDocument = c.GuaranteeDocument;
    x.Notes = c.Notes;
    x.OpgImageUrl = c.OpgImageUrl;
    x.ConsultantName = c.ConsultantName;
    x.ToothUnitCount = c.ServiceUnitCounts!.Values.Sum();
    x.Status = c.PrePaymentAmount + c.DepositAmount + paid >= c.TotalAmount
        ? PatientFinancialCaseStatus.Completed
        : PatientFinancialCaseStatus.Active;
    x.UpdatedAt = DateTime.UtcNow;
    await uow.SaveChangesAsync();
    return Result<PatientFinancialCaseIdResponse>.Success(new(x.Id));
  }
}
public sealed class CancelPatientFinancialCaseCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow, IFileStorageService storage)
    : ICommandHandler<CancelPatientFinancialCaseCommand,
                      PatientFinancialCaseIdResponse> {
  public async Task<Result<PatientFinancialCaseIdResponse>>
  HandleAsync(CancelPatientFinancialCaseCommand c,
              CancellationToken ct = default) {
    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var x = await repo.Cases.FirstOrDefaultAsync(x => x.Id == c.Id, ct);
      if (x is null) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinancialCaseIdResponse>.Failure("پرونده یافت نشد");
      }
      if (x.Status == PatientFinancialCaseStatus.Cancelled) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinancialCaseIdResponse>.Failure(
            "پرونده قبلاً حذف شده است");
      }
      var hasCheques = await repo.Cheques.AnyAsync(
          cheque => cheque.PatientFinancialCaseId == c.Id, ct);
      var hasNotes = await repo.PromissoryNotes.AnyAsync(
          note => note.PatientFinancialCaseId == c.Id, ct);
      if (hasCheques || hasNotes) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinancialCaseIdResponse>.Failure(
            "ابتدا همه چک‌ها و سفته‌های این پرونده را حذف کنید.");
      }
      if (await repo.Transactions.AnyAsync(transaction =>
              transaction.PatientFinancialCaseId == c.Id, ct) ||
          await repo.Debts.AnyAsync(debt => debt.PatientFinancialCaseId == c.Id, ct)) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinancialCaseIdResponse>.Failure(
            "سوابق پرداخت یا بدهی پرونده هنوز حذف نشده است.");
      }
      x.IsDeleted = true;
      x.DeletedAt = DateTime.UtcNow;
      x.Status = PatientFinancialCaseStatus.Cancelled;
      x.UpdatedAt = DateTime.UtcNow;
      var guaranteePath = x.GuaranteeDocument;
      await uow.CommitAsync(ct);
      storage.Delete(guaranteePath);
      return Result<PatientFinancialCaseIdResponse>.Success(new(x.Id));
    } catch {
      await uow.RollbackAsync(ct);
      throw;
    }
  }
}

public sealed class UpdatePatientChequeCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<UpdatePatientChequeCommand, PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>> HandleAsync(
      UpdatePatientChequeCommand c, CancellationToken ct = default) {
    if (c.AdditionalFields is { Count: > 0 })
      return Result<PatientFinanceIdResponse>.Failure(
          "درخواست شامل فیلد غیرمجاز است.");
    if (c.Amount <= 0)
      return Result<PatientFinanceIdResponse>.Failure(
          "مبلغ چک باید بیشتر از صفر باشد");
    if (string.IsNullOrWhiteSpace(c.OwnerName))
      return Result<PatientFinanceIdResponse>.Failure("نام صاحب چک الزامی است");
    if (c.OwnerName.Trim().Length > 200)
      return Result<PatientFinanceIdResponse>.Failure(
          "نام صاحب چک نمی‌تواند بیشتر از ۲۰۰ نویسه باشد");

    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var cheque = await repo.Cheques.Include(x => x.FinancialCase)
          .FirstOrDefaultAsync(x => x.Id == c.ChequeId, ct);
      if (cheque is null) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("چک یافت نشد");
      }
      if (string.IsNullOrWhiteSpace(c.SayadNumber) || c.SayadNumber.Trim().Length > 32 || c.DueDate == default) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("شماره صیادی یا تاریخ سررسید معتبر نیست");
      }
      var otherCommitments = await repo.Cheques
          .Where(x => x.PatientFinancialCaseId == cheque.PatientFinancialCaseId &&
                      x.Id != cheque.Id && !x.IsGuarantee)
          .SumAsync(x => (decimal?)x.Amount, ct) ?? 0;
      otherCommitments += await repo.PromissoryNotes
          .Where(x => x.PatientFinancialCaseId == cheque.PatientFinancialCaseId && !x.IsGuarantee)
          .SumAsync(x => (decimal?)x.Amount, ct) ?? 0;
      if (!c.IsGuarantee && otherCommitments + c.Amount > cheque.FinancialCase.TotalAmount) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "مجموع تعهدات نمی‌تواند از مبلغ کل پرونده بیشتر باشد");
      }
      var paidWithoutCurrentCheque = await repo.Transactions
          .Where(transaction =>
              transaction.PatientFinancialCaseId == cheque.PatientFinancialCaseId &&
              !(transaction.SourceType == PatientFinancialTransactionSourceType.Cheque &&
                transaction.SourceId == cheque.Id))
          .SumAsync(transaction => (decimal?)transaction.Amount, ct) ?? 0;
      var payment = await repo.Transactions.FirstOrDefaultAsync(transaction =>
          transaction.SourceType == PatientFinancialTransactionSourceType.Cheque &&
          transaction.SourceId == cheque.Id, ct);
      if (payment is not null) payment.Amount = c.Amount;
      var debt = await repo.Debts.FirstOrDefaultAsync(item =>
          item.SourceType == PatientDebtSourceType.Cheque && item.SourceId == cheque.Id, ct);
      if (debt is not null) debt.Amount = c.Amount;
      cheque.Amount = c.Amount;
      cheque.SayadNumber = c.SayadNumber.Trim();
      cheque.OwnerName = c.OwnerName.Trim();
      cheque.DueDate = c.DueDate;
      cheque.IsGuarantee = c.IsGuarantee;
      cheque.UpdatedAt = DateTime.UtcNow;
      var paidAfterUpdate = paidWithoutCurrentCheque + (payment is null ? 0 : c.Amount);
      cheque.FinancialCase.Status = cheque.FinancialCase.PrePaymentAmount +
          cheque.FinancialCase.DepositAmount + paidAfterUpdate >= cheque.FinancialCase.TotalAmount
          ? PatientFinancialCaseStatus.Completed
          : PatientFinancialCaseStatus.Active;
      await uow.CommitAsync(ct);
      return Result<PatientFinanceIdResponse>.Success(
          new(cheque.Id), "اطلاعات چک با موفقیت ویرایش شد.");
    } catch {
      await uow.RollbackAsync(ct);
      throw;
    }
  }
}

public sealed class UpdatePatientPromissoryNoteCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<UpdatePatientPromissoryNoteCommand,
                      PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>> HandleAsync(
      UpdatePatientPromissoryNoteCommand c, CancellationToken ct = default) {
    if (c.AdditionalFields is { Count: > 0 })
      return Result<PatientFinanceIdResponse>.Failure(
          "درخواست شامل فیلد غیرمجاز است.");
    if (c.Amount <= 0)
      return Result<PatientFinanceIdResponse>.Failure(
          "مبلغ سفته باید بیشتر از صفر باشد");

    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var note = await repo.PromissoryNotes.Include(x => x.FinancialCase)
          .FirstOrDefaultAsync(x => x.Id == c.PromissoryNoteId, ct);
      if (note is null) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("سفته یافت نشد");
      }
      if (string.IsNullOrWhiteSpace(c.SerialNumber) || c.SerialNumber.Trim().Length > 64 || c.DueDate == default) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("شماره سریال یا تاریخ سررسید معتبر نیست");
      }
      var otherCommitments = await repo.PromissoryNotes
          .Where(x => x.PatientFinancialCaseId == note.PatientFinancialCaseId &&
                      x.Id != note.Id && !x.IsGuarantee)
          .SumAsync(x => (decimal?)x.Amount, ct) ?? 0;
      otherCommitments += await repo.Cheques
          .Where(x => x.PatientFinancialCaseId == note.PatientFinancialCaseId && !x.IsGuarantee)
          .SumAsync(x => (decimal?)x.Amount, ct) ?? 0;
      if (!note.IsGuarantee && otherCommitments + c.Amount > note.FinancialCase.TotalAmount) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "مجموع تعهدات نمی‌تواند از مبلغ کل پرونده بیشتر باشد");
      }
      var paidWithoutCurrentNote = await repo.Transactions
          .Where(transaction =>
              transaction.PatientFinancialCaseId == note.PatientFinancialCaseId &&
              !(transaction.SourceType == PatientFinancialTransactionSourceType.PromissoryNote &&
                transaction.SourceId == note.Id))
          .SumAsync(transaction => (decimal?)transaction.Amount, ct) ?? 0;
      var payment = await repo.Transactions.FirstOrDefaultAsync(transaction =>
          transaction.SourceType == PatientFinancialTransactionSourceType.PromissoryNote &&
          transaction.SourceId == note.Id, ct);
      if (payment is not null) payment.Amount = c.Amount;
      var debt = await repo.Debts.FirstOrDefaultAsync(item =>
          item.SourceType == PatientDebtSourceType.PromissoryNote && item.SourceId == note.Id, ct);
      if (debt is not null) debt.Amount = c.Amount;
      note.Amount = c.Amount;
      note.SerialNumber = c.SerialNumber.Trim();
      note.DueDate = c.DueDate;
      note.UpdatedAt = DateTime.UtcNow;
      var paidAfterUpdate = paidWithoutCurrentNote + (payment is null ? 0 : c.Amount);
      note.FinancialCase.Status = note.FinancialCase.PrePaymentAmount +
          note.FinancialCase.DepositAmount + paidAfterUpdate >= note.FinancialCase.TotalAmount
          ? PatientFinancialCaseStatus.Completed
          : PatientFinancialCaseStatus.Active;
      await uow.CommitAsync(ct);
      return Result<PatientFinanceIdResponse>.Success(
          new(note.Id), "اطلاعات سفته با موفقیت ویرایش شد.");
    } catch {
      await uow.RollbackAsync(ct);
      throw;
    }
  }
}

public sealed class DeletePatientChequeCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<DeletePatientChequeCommand, PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>> HandleAsync(
      DeletePatientChequeCommand command, CancellationToken ct = default) {
    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var cheque = await repo.Cheques.Include(item => item.FinancialCase)
          .FirstOrDefaultAsync(item => item.Id == command.ChequeId, ct);
      if (cheque is null) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("چک یافت نشد");
      }
      var payments = await repo.Transactions.Where(transaction =>
          transaction.SourceType == PatientFinancialTransactionSourceType.Cheque &&
          transaction.SourceId == cheque.Id).ToListAsync(ct);
      var debts = await repo.Debts.Where(debt =>
          debt.SourceType == PatientDebtSourceType.Cheque && debt.SourceId == cheque.Id)
          .ToListAsync(ct);
      foreach (var payment in payments) { payment.IsDeleted = true; payment.DeletedAt = DateTime.UtcNow; }
      foreach (var debt in debts) { debt.IsDeleted = true; debt.DeletedAt = DateTime.UtcNow; debt.Status = PatientDebtStatus.Cancelled; }
      cheque.IsDeleted = true;
      cheque.DeletedAt = DateTime.UtcNow;
      var remainingPaid = await repo.Transactions.Where(transaction =>
          transaction.PatientFinancialCaseId == cheque.PatientFinancialCaseId &&
          !(transaction.SourceType == PatientFinancialTransactionSourceType.Cheque && transaction.SourceId == cheque.Id))
          .SumAsync(transaction => (decimal?)transaction.Amount, ct) ?? 0;
      cheque.FinancialCase.Status = cheque.FinancialCase.PrePaymentAmount +
          cheque.FinancialCase.DepositAmount + remainingPaid >= cheque.FinancialCase.TotalAmount
          ? PatientFinancialCaseStatus.Completed : PatientFinancialCaseStatus.Active;
      await uow.CommitAsync(ct);
      return Result<PatientFinanceIdResponse>.Success(new(cheque.Id), "چک و آثار مالی آن حذف شد.");
    } catch { await uow.RollbackAsync(ct); throw; }
  }
}

public sealed class DeletePatientPromissoryNoteCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<DeletePatientPromissoryNoteCommand, PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>> HandleAsync(
      DeletePatientPromissoryNoteCommand command, CancellationToken ct = default) {
    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var note = await repo.PromissoryNotes.Include(item => item.FinancialCase)
          .FirstOrDefaultAsync(item => item.Id == command.PromissoryNoteId, ct);
      if (note is null) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("سفته یافت نشد");
      }
      var payments = await repo.Transactions.Where(transaction =>
          transaction.SourceType == PatientFinancialTransactionSourceType.PromissoryNote &&
          transaction.SourceId == note.Id).ToListAsync(ct);
      var debts = await repo.Debts.Where(debt =>
          debt.SourceType == PatientDebtSourceType.PromissoryNote && debt.SourceId == note.Id)
          .ToListAsync(ct);
      foreach (var payment in payments) { payment.IsDeleted = true; payment.DeletedAt = DateTime.UtcNow; }
      foreach (var debt in debts) { debt.IsDeleted = true; debt.DeletedAt = DateTime.UtcNow; debt.Status = PatientDebtStatus.Cancelled; }
      note.IsDeleted = true;
      note.DeletedAt = DateTime.UtcNow;
      var remainingPaid = await repo.Transactions.Where(transaction =>
          transaction.PatientFinancialCaseId == note.PatientFinancialCaseId &&
          !(transaction.SourceType == PatientFinancialTransactionSourceType.PromissoryNote && transaction.SourceId == note.Id))
          .SumAsync(transaction => (decimal?)transaction.Amount, ct) ?? 0;
      note.FinancialCase.Status = note.FinancialCase.PrePaymentAmount +
          note.FinancialCase.DepositAmount + remainingPaid >= note.FinancialCase.TotalAmount
          ? PatientFinancialCaseStatus.Completed : PatientFinancialCaseStatus.Active;
      await uow.CommitAsync(ct);
      return Result<PatientFinanceIdResponse>.Success(new(note.Id), "سفته و آثار مالی آن حذف شد.");
    } catch { await uow.RollbackAsync(ct); throw; }
  }
}

public sealed class UpdatePatientChequeStatusCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<UpdatePatientChequeStatusCommand,
                      PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>>
  HandleAsync(UpdatePatientChequeStatusCommand c,
              CancellationToken ct = default) {
    if (c.Status is not (PatientChequeStatus.Paid or PatientChequeStatus.Unpaid))
      return Result<PatientFinanceIdResponse>.Failure("وضعیت مقصد معتبر نیست");
    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var x = await repo.Cheques.Include(x => x.FinancialCase)
                  .FirstOrDefaultAsync(x => x.Id == c.ChequeId, ct);
      if (x is null) {
        await uow.RollbackAsync();
        return Result<PatientFinanceIdResponse>.Failure("چک یافت نشد");
      }
      if (x.IsGuarantee) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("چک ضمانت سند پرداخت اقساط نیست؛ پس از عدم پرداخت اقساط، وصول آن باید از مسیر تسویه بدهی ثبت شود.");
      }
      if (x.Status != PatientChequeStatus.Pending) {
        await uow.RollbackAsync();
        return Result<PatientFinanceIdResponse>.Failure(
            "وضعیت چک قبلاً تعیین شده و قابل تغییر نیست");
      }
      if ((c.Status is PatientChequeStatus.Paid or PatientChequeStatus.Unpaid) &&
          IranTimeHelper.TodayInIran() < IranTimeHelper.GetDateInIran(x.DueDate)) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "ثبت نتیجه پرداخت فقط از روز سررسید امکان‌پذیر است");
      }
      if (c.Status == PatientChequeStatus.Paid) {var paid=await repo.Transactions.Where(t=>t.PatientFinancialCaseId==x.PatientFinancialCaseId).SumAsync(t=>(decimal?)t.Amount,ct)??0;
        if (paid + x.Amount + x.FinancialCase.PrePaymentAmount + x.FinancialCase.DepositAmount > x.FinancialCase.TotalAmount) {
          await uow.RollbackAsync();
          return Result<PatientFinanceIdResponse>.Failure(
              "پرداخت از مبلغ کل درمان بیشتر " +
              "می‌شود");
        }
        var legacyDebts = await repo.Debts
            .Where(d => d.SourceType == PatientDebtSourceType.Cheque &&
                        d.SourceId == x.Id &&
                        d.Status == PatientDebtStatus.Unpaid)
            .ToListAsync(ct);
        foreach (var debt in legacyDebts)
          debt.Status = PatientDebtStatus.Cancelled;
        await repo.AddTransactionAsync(
            new() { PatientFinancialCaseId = x.PatientFinancialCaseId,
                    Amount = x.Amount,
                    SourceType = PatientFinancialTransactionSourceType.Cheque,
                    SourceId = x.Id,
                    CreatedByUserId = c.ActorUserId },
            ct);
        if (paid + x.Amount + x.FinancialCase.PrePaymentAmount + x.FinancialCase.DepositAmount == x.FinancialCase.TotalAmount)
          x.FinancialCase.Status = PatientFinancialCaseStatus.Completed;
      } else if (c.Status == PatientChequeStatus.Unpaid) {
        if (await repo.Debts.AnyAsync(d => d.SourceType ==
                                               PatientDebtSourceType.Cheque &&
                                           d.SourceId == x.Id,
                                      ct)) {
          await uow.RollbackAsync();
          return Result<PatientFinanceIdResponse>.Failure(
              "برای این چک قبلاً بدهی ثبت شده است");
        }
        await repo.AddDebtAsync(
            new() { PatientFinancialCaseId = x.PatientFinancialCaseId,
                    Amount = x.Amount,
                    SourceType = PatientDebtSourceType.Cheque, SourceId = x.Id,
                    DueDate = x.DueDate },
            ct);
      }
      x.Status = c.Status;
      await uow.CommitAsync();
      return Result<PatientFinanceIdResponse>.Success(new(x.Id));
    } catch {
      await uow.RollbackAsync();
      throw;
    }
  }
}

public sealed class UpdatePatientPromissoryNoteStatusCommandHandler(
    IPatientFinanceRepository repo, IUnitOfWork uow)
    : ICommandHandler<UpdatePatientPromissoryNoteStatusCommand,
                      PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>>
  HandleAsync(UpdatePatientPromissoryNoteStatusCommand c,
              CancellationToken ct = default) {
    if (c.Status is not (PatientPromissoryNoteStatus.Paid or
                         PatientPromissoryNoteStatus.Unpaid))
      return Result<PatientFinanceIdResponse>.Failure("وضعیت مقصد معتبر نیست");
    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var x = await repo.PromissoryNotes.Include(x => x.FinancialCase)
                  .FirstOrDefaultAsync(x => x.Id == c.PromissoryNoteId, ct);
      if (x is null) {
        await uow.RollbackAsync();
        return Result<PatientFinanceIdResponse>.Failure("سفته یافت نشد");
      }
      if (x.IsGuarantee) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure("سفته ضمانت سند پرداخت نیست؛ دریافت واقعی اقساط باید جداگانه ثبت شود و مبلغ اسمی سفته به پرداخت یا بدهی تبدیل نمی‌شود.");
      }
      if (x.Status != PatientPromissoryNoteStatus.Pending) {
        await uow.RollbackAsync();
        return Result<PatientFinanceIdResponse>.Failure(
            "وضعیت سفته قبلاً تعیین شده و قابل تغییر نیست");
      }
      if ((c.Status is PatientPromissoryNoteStatus.Paid or PatientPromissoryNoteStatus.Unpaid) &&
          IranTimeHelper.TodayInIran() < IranTimeHelper.GetDateInIran(x.DueDate)) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "ثبت نتیجه پرداخت فقط از روز سررسید امکان‌پذیر است");
      }
      if (c.Status == PatientPromissoryNoteStatus.Paid) {var paid=await repo.Transactions.Where(t=>t.PatientFinancialCaseId==x.PatientFinancialCaseId).SumAsync(t=>(decimal?)t.Amount,ct)??0;
        if (paid + x.Amount + x.FinancialCase.PrePaymentAmount + x.FinancialCase.DepositAmount > x.FinancialCase.TotalAmount) {
          await uow.RollbackAsync();
          return Result<PatientFinanceIdResponse>.Failure(
              "پرداخت از مبلغ کل درمان بیشتر " +
              "می‌شود");
        }
        var legacyDebts = await repo.Debts
            .Where(d => d.SourceType == PatientDebtSourceType.PromissoryNote &&
                        d.SourceId == x.Id &&
                        d.Status == PatientDebtStatus.Unpaid)
            .ToListAsync(ct);
        foreach (var debt in legacyDebts)
          debt.Status = PatientDebtStatus.Cancelled;
        await repo.AddTransactionAsync(
            new() { PatientFinancialCaseId = x.PatientFinancialCaseId,
                    Amount = x.Amount,
                    SourceType =
                        PatientFinancialTransactionSourceType.PromissoryNote,
                    SourceId = x.Id,
                    CreatedByUserId = c.ActorUserId },
            ct);
        if (paid + x.Amount + x.FinancialCase.PrePaymentAmount + x.FinancialCase.DepositAmount == x.FinancialCase.TotalAmount)
          x.FinancialCase.Status = PatientFinancialCaseStatus.Completed;
      } else if (c.Status == PatientPromissoryNoteStatus.Unpaid) {
        if (await repo.Debts.AnyAsync(
                d => d.SourceType == PatientDebtSourceType.PromissoryNote &&
                     d.SourceId == x.Id,
                ct)) {
          await uow.RollbackAsync();
          return Result<PatientFinanceIdResponse>.Failure(
              "برای این سفته قبلاً بدهی ثبت شده است");
        }
        await repo.AddDebtAsync(
            new() { PatientFinancialCaseId = x.PatientFinancialCaseId,
                    Amount = x.Amount,
                    SourceType = PatientDebtSourceType.PromissoryNote,
                    SourceId = x.Id, DueDate = x.DueDate },
            ct);
      }
      x.Status = c.Status;
      await uow.CommitAsync();
      return Result<PatientFinanceIdResponse>.Success(new(x.Id));
    } catch {
      await uow.RollbackAsync();
      throw;
    }
  }
}

public sealed class PayPatientDebtCommandHandler(IPatientFinanceRepository repo,
                                                 IUnitOfWork uow)
    : ICommandHandler<PayPatientDebtCommand, PatientFinanceIdResponse> {
  public async Task<Result<PatientFinanceIdResponse>>
  HandleAsync(PayPatientDebtCommand c, CancellationToken ct = default) {
    await uow.BeginTransactionAsync(ct, IsolationLevel.Serializable);
    try {
      var d = await repo.Debts.Include(x => x.FinancialCase)
                  .FirstOrDefaultAsync(x => x.Id == c.DebtId, ct);
      if (d is null || d.Status != PatientDebtStatus.Unpaid) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "بدهی پرداخت‌نشده یافت نشد");
      }
      var hasPendingCommitment =
          await repo.Cheques.AnyAsync(
              x => x.PatientFinancialCaseId == d.PatientFinancialCaseId &&
                   !x.IsGuarantee && x.Status == PatientChequeStatus.Pending,
              ct) ||
          await repo.PromissoryNotes.AnyAsync(
              x => x.PatientFinancialCaseId == d.PatientFinancialCaseId &&
                   !x.IsGuarantee && x.Status == PatientPromissoryNoteStatus.Pending,
              ct);
      if (hasPendingCommitment) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "تا تعیین تکلیف همه چک‌ها و سفته‌های در گردش، تسویه کامل بدهی امکان‌پذیر نیست");
      }
      var st = d.SourceType == PatientDebtSourceType.Cheque
                   ? PatientFinancialTransactionSourceType.Cheque
                   : PatientFinancialTransactionSourceType.PromissoryNote;
      if (await repo.Transactions.AnyAsync(
              x => x.SourceType == st && x.SourceId == d.SourceId, ct)) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "این تعهد قبلاً پرداخت شده است");
      }
      var paid = await repo.Transactions
                       .Where(x => x.PatientFinancialCaseId ==
                                   d.PatientFinancialCaseId)
                       .SumAsync(x => (decimal?)x.Amount, ct) ?? 0;
      if (paid + d.Amount + d.FinancialCase.PrePaymentAmount + d.FinancialCase.DepositAmount > d.FinancialCase.TotalAmount) {
        await uow.RollbackAsync(ct);
        return Result<PatientFinanceIdResponse>.Failure(
            "پرداخت از مبلغ کل درمان بیشتر " +
            "می‌شود");
      }
      if (d.SourceType == PatientDebtSourceType.Cheque) {
        var source = await repo.Cheques.FirstOrDefaultAsync(
            x => x.Id == d.SourceId &&
                 x.Status == PatientChequeStatus.Unpaid,
            ct);
        if (source is null) {
          await uow.RollbackAsync(ct);
          return Result<PatientFinanceIdResponse>.Failure(
              "چک پرداخت‌نشده مرتبط با بدهی یافت نشد");
        }
        source.Status = PatientChequeStatus.Paid;
      } else {
        var source = await repo.PromissoryNotes.FirstOrDefaultAsync(
            x => x.Id == d.SourceId &&
                 x.Status == PatientPromissoryNoteStatus.Unpaid,
            ct);
        if (source is null) {
          await uow.RollbackAsync(ct);
          return Result<PatientFinanceIdResponse>.Failure(
              "سفته پرداخت‌نشده مرتبط با بدهی یافت نشد");
        }
        source.Status = PatientPromissoryNoteStatus.Paid;
      }
      await repo.AddTransactionAsync(
          new() { PatientFinancialCaseId = d.PatientFinancialCaseId,
                  Amount = d.Amount, SourceType = st, SourceId = d.SourceId,
                  CreatedByUserId = c.ActorUserId },
          ct);
      d.Status = PatientDebtStatus.Paid;
      if (paid + d.Amount + d.FinancialCase.PrePaymentAmount + d.FinancialCase.DepositAmount == d.FinancialCase.TotalAmount)
        d.FinancialCase.Status = PatientFinancialCaseStatus.Completed;
      await uow.CommitAsync(ct);
      return Result<PatientFinanceIdResponse>.Success(new(d.Id));
    } catch {
      await uow.RollbackAsync(ct);
      throw;
    }
  }
}
