using DentalDashboard.ApplicationService.Contract.Responses;
using DentalDashboard.ApplicationService.Contract.Responses.ReservationResponse;
using DentalDashboard.Framwork.Cqrs.Abstraction.Read;

namespace DentalDashboard.ApplicationService.Contract.Requests.Reservation.Queries
{
    public class GetConsultantPatientProfilesQuery : IQuery<PaginatedResult<ConsultantPatientProfileItemResponse>>
    {
        public long ConsultantProfileId { get; set; }
        public DateTime? From { get; set; }
        public DateTime? To { get; set; }
        public string? SearchText { get; set; }
        public string? Search { get; set; }
        public int? Page { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }
}
