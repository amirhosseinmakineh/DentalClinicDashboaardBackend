using DentalDashboard.Domain.Enums;

namespace DentalDashboard.Domain.Models;

public class LeadAssignment : BaseAuditableEntity<long>
{
    public LeadSourceType SourceType { get; set; } = LeadSourceType.Yektanet;
    public string UserName { get; set; } = default!;

    public string PhoneNumber { get; set; } = default!;

    public LeadAssignmentState LeadAssignmentState { get; set; }

    public long? ConsultantProfileId { get; set; }

    public ConsultantProfile? ConsultantProfile { get; set; }

    public DateTime? AssignedAt { get; set; }

    public LeadAssignmentType AssignmentType { get; set; }

    public DateTime? CallDeadlineAt { get; set; }

    public bool RequiresThreeMinuteCall { get; set; }

    public bool NotificationSent { get; set; }

    public string? ReportDescription { get; set; }

    public DateTime? ReportSubmittedAt { get; set; }

    public DateTime? ContactedAt { get; set; }

    public DateTime? CallInitiatedAt { get; set; }

    public LeadCallResult? CallResult { get; set; }

    public bool SmsSent { get; set; }

    public string? PatientCity { get; set; }

    public string? PatientRegion { get; set; }

    public string? BusinessName { get; set; }

    public int? AttendanceProbabilityPercent { get; set; }

    public string? SecondaryPhoneNumber { get; set; }

    // RealTime Pickup
    public bool PickUp { get; set; }
    public int DispatchLevel { get; set; }

    public DateTime? LastDispatchAt { get; set; }

    public DateTime? ClosedByConsultantAt { get; set; }

    public LeadClosureReason? ClosureReason { get; set; }

    public string? ClosureDescription { get; set; }
}
